# AIoT 디지털 트윈 관제 시스템 v2 (OpenAI 버전)
# AIoT 가상 텔레메트리 기반 디지털 트윈 관제 시스템 v2 (OpenAI 버전)
## 디지털 트윈 기술을 활용한 AIoT 가상 텔레메트리 기반 실내 이상 감지 및 대응 에이전트


## 프로젝트 구조

```
aiot-twin/
├── backend/
│   ├── data/  # pkl 파일 저장
|   |── app
│   │   ├── models/
│   │   │   └── twin.py              # 디지털 트윈 핵심 모델 (RoomTwin, BuildingTwin)
│   │   ├── core/
│   │   │   └── building_factory.py  # 데모 건물 초기화 (5개 공간, 가상 센서 부착)
│   │   └── services/
│   │         └── ai_models/                    ← 폴더째 추가
│   │             ├── __init__.py               ← 빈 파일 생성
│   │             ├── smoking_detector.py       ← 새로 추가
│   │             └── fire_detector.py          ← 새로 추가
|   |       ├── ensemble_detector.py          ← 새로 추가
│   │       ├── smoking_generator.py          ← 새로 추가
│   │       ├── generator.py         # 가상 텔레메트리 제너레이터 + LSTM 예측 엔진
│   │       └── agent.py             # AIoT Agent (이상 감지 → OpenAI API → 조치 생성)
│   ├── main.py                      # FastAPI 앱 (WebSocket + REST API)
│   ├── requirements.txt
│   └── .env
├── frontend/
|   |── node_module/
│   ├── src/
│   │   ├── components/
            └── FireCameraPanel.jsx           ← 새로 추가
│   │   │   ├── BuildingTwinViewer.jsx  # Three.js 3D 빌딩 시각화
│   │   │   └── RoomDetailPanel.jsx     # 실시간 센서 패널 + AI 결과 카드
│   │   ├── App.jsx                     # 메인 레이아웃 + WebSocket + 채팅
│   │   └── main.jsx
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
|   └── package-lock.json
└── README.md
```

generator.py (센서 생성)
   ↓
main.py (_collect_all_readings)
   ↓
WebSocket (/ws/telemetry)
   ↓
App.jsx (onmessage)
   ↓
telemetry state 저장
   ↓
RoomDetailPanel props로 전달

####
readings: {
  temperature: 22.5,      // 온도 (°C)
  humidity: 45,           // 습도 (%)
  co2: 450,              // CO2 농도 (ppm)
  light_level: 800,      // 조도 (lux)
  air_quality: "good",   // 공기질
  noise_level: 55        // 소음도 (dB)
}


## 변경 사항
- Anthropic → **OpenAI GPT-4o-mini** 로 교체
- Grafana / InfluxDB 제거 (설치 불필요)
- 다크 테마 Three.js 3D 뷰 개선

---

## 빠른 시작

### 1. API 키 설정
```
backend/.env.example → backend/.env 로 복사 후
OPENAI_API_KEY=sk-proj-... 입력
```

### 2. 백엔드 실행
```bash
cd backend
#python -m venv venv
#venv\Scripts\activate          # Windows
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

### 3. 프론트엔드 실행 (새 터미널)
```bash
cd frontend
npm install
npm run dev
# http://127.0.0.1:5174
```

---

## 시연 순서
1. 브라우저에서 `http://localhost:5174` 접속
2. 3D 뷰에서 공간 클릭 → 우측 센서 패널 확인
3. 하단 시나리오 버튼 클릭 (공간 선택 후)
4. "AI 이상 분석 실행" → GPT 원인 분석 + 작업지시서 자동 생성
5. 하단 채팅: "지금 위험한 공간 어디야?" 입력

---

## API 문서
`http://localhost:8000/docs` — Swagger UI
