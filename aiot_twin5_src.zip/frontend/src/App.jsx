/**
 * App.jsx - ML 기반 ensemble 엔드포인트 활용
 * 
 * 추가 기능:
 * 1. ML 기반 실시간 이상 탐지 (realtime/anomaly)
 * 2. 건물 종합 이상 상태 모니터링 (anomaly-summary)
 * 3. 센서별 독립적 분석 (analyze/ensemble)
 */
import { useState, useEffect, useRef, useCallback } from "react";
import BuildingTwinViewer from "./components/BuildingTwinViewer";
import { RoomDetailPanel } from "./components/RoomDetailPanel";

import FireCameraPanel from "./components/FireCameraPanel";

// 변경 전
// const API = "http://localhost:8000";
// const WS  = "ws://localhost:8000/ws/telemetry";

// 변경 후
const API = "";                        // Vite 프록시 사용 (상대 경로)
const WS  = "ws://127.0.0.1:8000/ws/telemetry";  // 직접 연결

const SCENARIOS = [
  { id: "co2_spike",       label: "CO₂ 급증",  color: "#185FA5" },
  { id: "overheating",     label: "과열",       color: "#7B1F1F" },
  { id: "humidity_crisis", label: "습도 위기",  color: "#0F5E3A" },
  { id: "multi_alarm",     label: "복합 경보",  color: "#7A4500" },
  { id: "normal",          label: "정상 복구",  color: "#2a3a2a" },
];

const S = {
  panel: {
    // width: 500,
    // width 제거 (동적으로 제어)
    flexShrink: 0,
    background: "#12141c",
    borderLeft: "1px solid #1e2130",
    display: "flex",
    flexDirection: "column",
    overflow: "hidden",
  }
}

export default function App() {

  const threeRef = useRef(null); 

  const [rooms,        setRooms]        = useState([]);
  const [telemetry,    setTelemetry]    = useState({});
  const [historyMap,   setHistoryMap]   = useState({});
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [aiResult,     setAiResult]     = useState(null);
  const [analyzing,    setAnalyzing]    = useState(false);
  const [summary,      setSummary]      = useState(null);
  const [agentLog,     setAgentLog]     = useState([]);
  const [chatMsgs,     setChatMsgs]     = useState([
    { role: "system", text: "AIoT 관제 에이전트 (GPT-4o-mini) 준비 완료." },
  ]);
  const [chatInput,    setChatInput]    = useState("");
  const [chatLoading,  setChatLoading]  = useState(false);
  const [wsStatus,     setWsStatus]     = useState("연결 중");
  const chatEndRef = useRef(null);
  const wsRef      = useRef(null);

  const [rightTab, setRightTab] = useState("sensor");
  // {rightTab === "camera" && (
  //   <FireCameraPanel roomId={selectedRoom} />
  // )}

  const [panelWidth, setPanelWidth] = useState(480);
  const isDragging = useRef(false);

  // 새로 추가: ML 기반 이상 탐지 결과
  const [mlAnomalies, setMlAnomalies] = useState({});  // room_id -> anomaly result
  const [buildingSummary, setBuildingSummary] = useState(null);

  // 공간 목록 로드
  useEffect(() => {
    fetch(`${API}/api/rooms`)
      .then(r => r.json())
      .then(setRooms)
      .catch(() => {});
  }, []);

  // 새로 추가: 건물 종합 이상 상태 폴링
  useEffect(() => {
    const poll = async () => {
      try {
        const res = await fetch(`${API}/api/building/anomaly-summary`);
        const data = await res.json();
        setBuildingSummary(data);
        // console.log("[건물 종합 분석]", data);
      } catch (e) {
        console.error("건물 분석 폴링 오류:", e);
      }
    };

    poll();
    const id = setInterval(poll, 5000);  // 5초마다 폴링
    return () => clearInterval(id);
  }, []);

  // 새로 추가: 실시간 센서 이상 탐지 폴링 (모든 공간)
  useEffect(() => {
    const pollAnomalies = async () => {
      try {
        const results = {};
        for (const room of rooms) {

          try {                                              // ✅ 방 단위 try-catch 추가
            const res = await fetch(`${API}/api/realtime/anomaly/${room.room_id}`);
            if (!res.ok) continue;                          // ✅ 500이면 skip
            const data = await res.json();
            results[room.room_id] = data;
          } catch (roomErr) {
            console.warn(`[skip] ${room.room_id}:`, roomErr.message);
          }


        }
        setMlAnomalies(results);
      } catch (e) {
        console.error("실시간 이상 탐지 폴링 오류:", e);
      }
    };

    if (rooms.length > 0) {
      pollAnomalies();
      const id = setInterval(pollAnomalies, 3000);  // 3초마다 폴링
      return () => clearInterval(id);
    }
  }, [rooms]);

  // WebSocket 연결
  useEffect(() => {
    let ws = null;
    let retryTimer = null;
    let stopped = false;
    let connectCount = 0;

    const connect = () => {
      if (stopped) return;

      // 이미 열려있으면 재연결 안 함
      if (ws && ws.readyState === WebSocket.OPEN) return;

      connectCount++;
      const currentCount = connectCount;

      try {
        ws = new WebSocket("ws://127.0.0.1:8000/ws/telemetry");
        wsRef.current = ws;
      } catch (e) {
        retryTimer = setTimeout(connect, 3000);
        return;
      }

      ws.onopen = () => {
        if (currentCount !== connectCount) return;
        setWsStatus("연결됨");
      };

      ws.onclose = () => {
        if (stopped) return;
        setWsStatus("재연결 중");
        retryTimer = setTimeout(connect, 3000);
      };

      ws.onerror = () => {
        // 오류 시 close 이벤트가 자동 발생
      };

      ws.onmessage = (e) => {
        try {
          const data = JSON.parse(e.data);
          setSummary(data.building);
          setTelemetry(data.rooms || {});
          setHistoryMap(prev => {
            const next = { ...prev };
            Object.entries(data.rooms || {}).forEach(([rid, room]) => {
              next[rid] = [...(next[rid] || []), { readings: room.readings }].slice(-120);
            });
            return next;
          });
        } catch (_) {}
      };
    };

    // 백엔드 준비 대기 후 연결 (500ms 딜레이)
    retryTimer = setTimeout(connect, 500);

    return () => {
      stopped = true;
      clearTimeout(retryTimer);
      if (ws) {
        ws.onclose = null;
        ws.close();
      }
    };
  }, []);

  // 에이전트 로그 폴링
  useEffect(() => {
    const poll = () => fetch(`${API}/api/agent/log?limit=8`).then(r => r.json()).then(setAgentLog).catch(() => {});
    poll();
    const id = setInterval(poll, 5000);
    return () => clearInterval(id);
  }, []);

  // useEffect로 드래그 이벤트 등록
  useEffect(() => {
    const onMove = (e) => {
      if (!isDragging.current) return;
      const newW = window.innerWidth - e.clientX;
      setPanelWidth(Math.max(280, Math.min(700, newW)));
    };
    const onUp = () => { isDragging.current = false; };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup",   onUp);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup",   onUp);
    };
  }, []);

  // useState 추가
  const [alertRooms, setAlertRooms] = useState([]);

  // useEffect 추가 (경보 폴링)
  useEffect(() => {
    const id = setInterval(() =>
      fetch(`${API}/api/alerts/active`)
        .then(r => r.json())
        .then(d => setAlertRooms(d.alerts || [])), 2000);
    return () => clearInterval(id);
  }, []);

  // 시나리오 주입
  const injectScenario = async (scenarioId) => {
    if (!selectedRoom) { alert("먼저 3D 뷰에서 공간을 클릭해 선택하세요."); return; }

    try {
      const res = await fetch(`${API}/api/scenario`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          room_id: selectedRoom,
          scenario: scenarioId,
          duration: 60,
        }),
      });

      const data = await res.json();

      // 👉 여기 추가
      setChatMsgs(m => [
        ...m,
        { role: "system", text: data.message }
      ]);

    } catch (e) {
      console.error(e);
    }

  };

  // 3D 뷰어용 rooms 배열 (실시간 상태 포함)
  const liveRooms = rooms.map(r => ({
    ...r,
    status:             telemetry[r.room_id]?.status             || "정상",
    readings:           telemetry[r.room_id]?.readings           || {},
    sensors_meta:       telemetry[r.room_id]?.sensors_meta       || {},
    occupancy_estimate: telemetry[r.room_id]?.occupancy_estimate || 0,
  }));

  const selRoomData = selectedRoom ? liveRooms.find(r => r.room_id === selectedRoom) : null;

  // AI 분석 실행 , 변경: ML 기반 ensemble 분석 사용
  const runAnalysis = useCallback(async () => {
    if (!selectedRoom) return;
    setAnalyzing(true);
    setAiResult(null);
    try {
       // ✅ 현재 실시간 센서값을 body에 포함
      const currentReadings = selRoomData?.readings || {};
      const sensorsMeta     = selRoomData?.sensors_meta || {};

      // ML 앙상블 분석 요청
      const res = await fetch(`${API}/api/analyze/ensemble/${selectedRoom}`, { 
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          readings:     currentReadings,   // 현재 센서값 전달
          sensors_meta: sensorsMeta,       // 임계값 정보 전달
          room_id:      selectedRoom,
          timestamp:    new Date().toISOString(),
        })
      });

      const data = await res.json();
      console.log("ML 앙상블 현재값:", currentReadings);       
      console.log("ML 앙상블 분석 결과:", data);       
      // console.log("aiResult 설정값:", data.status === "normal" ? null : data);  

      // 분석 결과를 AI 분석 결과 형식으로 변환
      const analysisResult = data.analysis_result;
      
      // 종합 상태 판정
      const severity = analysisResult.overall_status;
      const abnormalSensors = analysisResult.sensors.filter(s => s.is_abnormal);

      // AI 분석 결과와 유사한 형식으로 변환
      setAiResult({
        room_name: selRoomData?.name || "",
        ai_analysis: {
          severity: analysisResult.overall_status,
          // severity: severity,
          cause: abnormalSensors.length > 0 
            ? `${abnormalSensors.map(s => s.message).join(", ")}`
            : "모든 센서가 정상 범위 내입니다.",
          actions: abnormalSensors.length > 0 
            ? [
                `즉시 ${abnormalSensors[0].sensor} 확인`,
                "환기 또는 냉각 실시",
                "센서 재보정 검토"
              ]
            : ["현재 상태 유지", "정기 모니터링 계속"],
          predicted_risk: abnormalSensors.length > 0 ? "추가 모니터링 필요" : "이상 없음",
          confidence: Math.max(...analysisResult.sensors.map(s => s.abnormal_prob * 100 || 0)).toFixed(0),
          // ✅ 분석 시점 스냅샷 저장 (UI에서 "분석 당시 값" 표시 가능)
          snapshot: currentReadings,
        },
        work_order: null,
        ml_details: analysisResult,  // 상세 ML 분석 결과 포함
      });
    } catch (e) {
      console.error("분석 실패:", e);
      setAiResult({
        room_name: "오류",
        ai_analysis: {
          severity: "경고",
          cause: `분석 실패: ${e.message}`,
          actions: ["백엔드 서버 상태 확인", "API 키 확인"],
          predicted_risk: "-",
          confidence: 0,
        },
        work_order: null,
      });
    }
    setAnalyzing(false);
  }, [selectedRoom,selRoomData]);

  // 채팅 전송
  const sendChat = async () => {
    if (!chatInput.trim() || chatLoading) return;
    const q = chatInput.trim();
    setChatMsgs(m => [...m, { role: "user", text: q }]);
    setChatInput("");
    setChatLoading(true);
    try {
      const res  = await fetch(`${API}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: q }),
      });
      const data = await res.json();
      setChatMsgs(m => [...m, { role: "agent", text: data.answer }]);
    } catch {
      setChatMsgs(m => [...m, { role: "agent", text: "서버 연결 오류" }]);
    }
    setChatLoading(false);
    setTimeout(() => chatEndRef.current?.scrollIntoView({ behavior: "smooth" }), 80);
  };



  return (
    <div style={{ height: "100vh", display: "flex", flexDirection: "column", background: "#0f0f14" }}>

      {/* ── 헤더 ── */}
      <header style={{
        padding: "0 20px", height: 50,
        display: "flex", alignItems: "center", justifyContent: "space-between",
        background: "#12141c", borderBottom: "1px solid #1e2130", flexShrink: 0,
      }}>  
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{
            width: 8, height: 8, borderRadius: "50%", display: "inline-block",
            background: wsStatus === "연결됨" ? "#1D9E75" : "#E24B4A",
            boxShadow: wsStatus === "연결됨" ? "0 0 6px #1D9E75" : "none",
          }} />
          <span style={{ fontSize: 14, fontWeight: 600, color: "#c8c6be", letterSpacing: 0.3 }}>
            AIoT 디지털 트윈 관제 시스템
          </span>
          {/* <span style={{ fontSize: 10, color: "#445", marginLeft: 4 }}>OpenAI GPT-4o-mini</span> */}
          <span style={{ fontSize: 10, color: "#fff", marginLeft: 4 }}>
            🤖 GPT-4o-mini + ML 앙상블 (XGBoost+RF+LR)
          </span>
        </div>

        {/* 건물 요약 + ML 상태 */}
        {summary && (
          <div style={{ display: "flex", gap: 18, fontSize: 12 }}>
            {[["정상", "#1D9E75"], ["경고", "#EF9F27"], ["위험", "#E24B4A"]].map(([k, c]) => (
              <span key={k} style={{ color: c }}>
                {k} <strong>{summary.status?.[k] ?? 0}</strong>
              </span>
            ))}
            <span style={{ color: "#445", fontSize: 11 }}>{summary.building}</span>
            {/*  ML 기반 이상 감지 현황 */}
            {buildingSummary && (
              <span style={{ color: "#EF9F27", fontSize: 10, marginLeft: 10 }}>
                | 🤖 ML 감지: 위험 {buildingSummary.critical_count} · 경고 {buildingSummary.warning_count}
              </span>
            )}
          </div>
        )}
      </header>

      {/* ── 메인 ── */}
      <div style={{ flex: 1, display: "flex", overflow: "auto" }}>

        {/* 3D 트윈 뷰 */}
        <div id="three-view" ref={threeRef} style={{ flex: 1, position: "relative", minWidth: 0, background: "#090b10" }}>
          {liveRooms.length > 0 && (
            <BuildingTwinViewer
              rooms={liveRooms}
              selectedRoomId={selectedRoom}
              onRoomClick={(rid) => { setSelectedRoom(rid); setAiResult(null); }}
              alertRooms={alertRooms}          
            />
          )}

          {/* 시나리오 버튼 (하단) */}
          <div style={{
            position: "absolute", bottom: 14, left: "50%", transform: "translateX(-50%)",
            display: "flex", gap: 6,
          }}>
            {SCENARIOS.map(s => (
              <button 
                key={s.id} 
                onClick={() => injectScenario(s.id)} 
                style={{
                  padding: "5px 13px", 
                  borderRadius: 20, 
                  border: "1px solid #334",
                  background: s.color, 
                  color: "#ddd",
                  fontSize: 11, 
                  fontWeight: 600, 
                  cursor: "pointer", 
                  letterSpacing: 0.2,
                  transition: "all 0.25s ease",  // 트랜지션
                  boxShadow: "0 2px 4px rgba(0,0,0,0.2)",  // 기본 그림자
                }}
                onMouseEnter={(e) => {  // 마우스 진입
                  e.target.style.filter = "brightness(1.3)";      // 밝기 증가
                  e.target.style.transform = "scale(1.08)";        // 확대
                  e.target.style.boxShadow = "0 6px 16px rgba(0,0,0,0.35)";  // 그림자 강화
                }}
                onMouseLeave={(e) => {  // 마우스 이탈
                  e.target.style.filter = "brightness(1)";         // 원래 밝기
                  e.target.style.transform = "scale(1)";           // 원래 크기
                  e.target.style.boxShadow = "0 2px 4px rgba(0,0,0,0.2)";  // 원래 그림자
                }}
              >
                {s.label}
              </button>
            ))}
          </div>

          {/* 선택 안내 */}
          {!selectedRoom && (
            <div style={{
              position: "absolute", top: 14, left: "50%", transform: "translateX(-50%)",
              background: "rgba(10,12,20,0.8)", border: "1px solid #334",
              borderRadius: 6, padding: "5px 14px", fontSize: 11, color: "#778",
              pointerEvents: "none",
            }}>
              공간을 클릭하여 선택 → 우측에서 센서값 확인 및 AI/ML 분석
            </div>
          )}
        </div>

        {/* 드래그 핸들 */}
        <div
          onMouseDown={() => { isDragging.current = true; }}
          style={{
            width: 4, flexShrink: 0, cursor: "col-resize",
            background: "transparent",
            borderLeft: "2px solid #2a2d3a",
            transition: "border-color 0.2s",
          }}
          onMouseEnter={e => e.target.style.borderColor = "#534AB7"}
          onMouseLeave={e => e.target.style.borderColor = "#2a2d3a"}
        />

        {/* ── 우측 패널 ── */}
        <div style={{ ...S.panel, width: panelWidth }}>
          {/* 탭 헤더 */}
          <div style={{
              display: "flex",
              padding: 6,
              background: "#111827",
              borderBottom: "1px solid #1f2937",
            }}>  
            {[["sensor","센서 모니터"],["fire","화재·흡연 카메라"]].map(([id,label]) => {
              const active = rightTab === id;

              return (
                <button
                  key={id}
                  onClick={() => setRightTab(id)}
                  style={{
                    flex: 1,
                    padding: "10px 0",
                    borderRadius: 8,
                    border: "none",
                    fontSize: 12,
                    fontWeight: 700,
                    background: active ? "#ffffff" : "transparent",
                    color: active ? "#111" : "#d1d5db",
                    boxShadow: active ? "0 2px 6px rgba(0,0,0,0.1)" : "none",
                    transition: "all 0.2s",
                    cursor: "pointer",
                  }}
                >
                  {label}
                </button>
              );
            })}
          </div>
        
          <div style={{flex:1, overflowY:"auto", display: rightTab==="sensor" ? "block":"none"}}>
            <RoomDetailPanel
              roomData={selRoomData}
              history={selectedRoom ? historyMap[selectedRoom] : null}
              aiResult={aiResult}
              onAnalyze={runAnalysis}
              analyzing={analyzing}
              mlAnomaly={selectedRoom ? mlAnomalies[selectedRoom] : null}
            />
          </div>
        
          <div style={{flex:1, overflowY:"auto", display: rightTab==="fire" ? "block":"none"}}>
            <FireCameraPanel rooms={rooms} selectedRoom={selectedRoom} setSelectedRoom={setSelectedRoom} threeRef={threeRef} />
          </div>
        
          {rightTab==="sensor" && agentLog.length>0 && (
            <div style={{padding:"8px 12px", borderTop:"1px solid #1e2130",
              maxHeight:110, overflowY:"auto", flexShrink:0}}>
              <div style={{fontSize:10, color:"#fff", marginBottom:5}}>에이전트 이벤트</div>
              {[...agentLog].reverse().map((log,i)=>{
                const sev=log.ai_analysis?.severity;
                const c=sev==="위험"?"#E24B4A":"#EF9F27";
                return (
                  <div key={i} style={{fontSize:10,color:"#fff",padding:"3px 0",borderBottom:"1px solid #1a1d28"}}>
                    <span style={{color:c,marginRight:5}}>[{sev}]</span>
                    {log.room_name}: {log.ai_analysis?.cause?.slice(0,35)}...
                  </div>
                );
              })}
            </div>
          )}
        </div>  
        
      </div>

      {/* ── 채팅 인터페이스 ── */}
      {/* <div style={S.chatWrap}> */}
      <div style={{
        height: 190, display: "flex", flexDirection: "column",
        background: "#12141c", borderTop: "1px solid #1e2130", flexShrink: 0,
      }}>
        {/* 메시지 목록 */}
        <div style={{
          height: "100px",
          display: "flex",
          flexDirection: "column"
        }}>
          <div style={{
            flex: 1, overflowY: "auto", padding: "8px 16px",
            display: "flex", flexDirection: "column", gap: 6,
          }}>
            {[...chatMsgs].reverse().map((m, i) => (  
              <div key={i} style={{
                alignSelf: m.role === "user" ? "flex-end" : "flex-start",
                maxWidth: "78%",
                background: m.role === "user" ? "#534AB7"
                  : m.role === "system" ? "#151820"
                  : "#1a1d28",
                color: m.role === "user" ? "#EEEDFE" : "#fff",
                borderRadius: 8, padding: "6px 11px",
                fontSize: 12, lineHeight: 1.6,
                border: m.role === "system" ? "1px solid #2a2d3a" : "none",
              }}>
                {m.text}
              </div>
            ))}
            {chatLoading && (
              <div style={{ alignSelf: "flex-start", fontSize: 11, color: "#445" }}>
                GPT + ML 분석 중...
              </div>
            )}
            <div ref={chatEndRef} />
          </div>
        </div>

        {/* 입력창 */}
        <div style={{
          padding: "7px 14px", display: "flex", gap: 8,
          borderTop: "1px solid #1e2130",
        }}>
          <input
            value={chatInput}
            onChange={e => setChatInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && sendChat()}
            placeholder="예: ML이 감지한 이상 공간은? / CO2가 높은 곳은?"
            style={{
              flex: 1, padding: "7px 12px", borderRadius: 7,
              border: "1px solid #2a2d3a", background: "#151820",
              color: "#c8c6be", fontSize: 12, outline: "none",
            }}
          />
          <button onClick={sendChat} style={{
            padding: "7px 16px", borderRadius: 7, border: "none",
            background: "#534AB7", color: "#EEEDFE",
            fontSize: 12, fontWeight: 600, cursor: "pointer",
          }}>
            전송
          </button>
        </div>
      </div>
    </div>
  );
}