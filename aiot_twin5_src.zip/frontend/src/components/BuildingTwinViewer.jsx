/**
 * Three.js 3D 빌딩 뷰어 - 화재/흡연 경보 표시 기능 추가
 * - 화재 공간: 빨간색 점멸 + 불꽃 파티클
 * - 흡연 공간: 주황색 점멸
 * - 경보 발생 시 해당 공간 위에 경보 레이블 표시
 */
import { useRef, useEffect, useState } from "react";
import * as THREE from "three";

const STATUS_COLOR = {
  "정상": 0x1D9E75,
  "경고": 0xEF9F27,
  "위험": 0xE24B4A,
};
const STATUS_OPACITY = { "정상": 0.4, "경고": 0.7, "위험": 0.85 };

// 경보 타입별 색상
const ALERT_COLOR = {
  "fire":  0xFF2200,
  "smoke": 0xFFEE00,
};

export default function BuildingTwinViewer({ rooms, selectedRoomId, onRoomClick, alertRooms = [] }) {
  const mountRef   = useRef(null);
  const meshMapRef = useRef({});
  const frameRef   = useRef(null);
  const labelMapRef = useRef({});   // 경보 레이블 (CSS2D 대신 Three.js Sprite 사용)
  const [hovered, setHovered] = useState(null);

  // alertRooms: [{room_id, alert_type}, ...]
  const alertMap = Object.fromEntries((alertRooms || []).map(a => [a.room_id, a.alert_type]));

  // ── 씬 초기화 ──────────────────────────────────────
  useEffect(() => {
    if (!mountRef.current || rooms.length === 0) return;
    const W = mountRef.current.clientWidth  || 600;
    const H = mountRef.current.clientHeight || 400;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(W, H);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x000000, 0);
    mountRef.current.appendChild(renderer.domElement);

    const scene  = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, W / H, 0.1, 200);
    camera.position.set(22, 20, 24);
    camera.lookAt(5, 4, 2);

    // 조명
    scene.add(new THREE.AmbientLight(0xffffff, 0.5));
    const dir = new THREE.DirectionalLight(0xffffff, 0.9);
    dir.position.set(15, 25, 15);
    scene.add(dir);

    // 바닥 그리드
    const grid = new THREE.GridHelper(40, 20, 0x333333, 0x222222);
    grid.position.set(4, -0.05, 2);
    scene.add(grid);

    // 층 구분선
    // [0, 4, 8, 11].forEach(y => {
    //   const geo = new THREE.EdgesGeometry(new THREE.BoxGeometry(14, 0.02, 12));
    //   const mat = new THREE.LineBasicMaterial({ color: 0x334455, opacity: 0.4, transparent: true });
    //   const mesh = new THREE.LineSegments(geo, mat);
    //   mesh.position.set(4, y, 2);
    //   scene.add(mesh);
    // });

    // 🔥 1. 층별 그룹핑
    const floorMap = {};
    rooms.forEach(room => {
      const floor = room.floor ?? 0; // floor 없으면 0층 처리
      if (!floorMap[floor]) floorMap[floor] = [];
      floorMap[floor].push(room);
    });

    // 🔥 2. y 자동 정렬
    let currentY = 0;

    Object.keys(floorMap)
      .sort((a, b) => a - b)
      .forEach(floor => {
        const floorRooms = floorMap[floor];

        // 해당 층 최대 높이
        const maxH = Math.max(...floorRooms.map(r => r.position.h));

        floorRooms.forEach(room => {
          room.position.y = currentY; // ✅ 강제로 붙임
        });

        currentY += maxH; // 다음 층으로 이동
      });
      
    // 공간 메시 생성
    const meshMap   = {};
    const labelMap  = {};

    rooms.forEach(room => {
      const p = room.position;
      if (!p) return;

      // 공간 박스
      const geo = new THREE.BoxGeometry(p.w - 0.1, p.h, p.d - 0.1);
      const mat = new THREE.MeshPhongMaterial({
        color: STATUS_COLOR["정상"],
        transparent: true,
        opacity: STATUS_OPACITY["정상"],
        depthWrite: false,
        shininess: 30,
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(p.x + p.w / 2, p.y + p.h / 2, p.z + p.d / 2);
      mesh.userData = { room_id: room.room_id, name: room.name };
      scene.add(mesh);
      meshMap[room.room_id] = mesh;

      // 와이어프레임
      const edges = new THREE.EdgesGeometry(geo);
      const line  = new THREE.LineSegments(edges,
        new THREE.LineBasicMaterial({ color: 0x556677, opacity: 0.6, transparent: true }));
      line.position.copy(mesh.position);
      scene.add(line);

      // 경보 레이블 스프라이트 (텍스처 캔버스)
      const sprite = _makeAlertSprite("");
      sprite.position.set(
        p.x + p.w / 2,
        p.y + p.h + 1.2,
        p.z + p.d / 2
      );
      sprite.visible = false;
      scene.add(sprite);
      labelMap[room.room_id] = sprite;
    });


    meshMapRef.current  = meshMap;
    labelMapRef.current = labelMap;

    // ── Raycasting ──────────────────────────────────
    const raycaster = new THREE.Raycaster();
    const mouse     = new THREE.Vector2();
    const allMeshes = Object.values(meshMap);

    const getNDC = (e) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x =  ((e.clientX - rect.left) / rect.width)  * 2 - 1;
      mouse.y = -((e.clientY - rect.top)  / rect.height) * 2 + 1;
    };
    const onMove  = (e) => { getNDC(e); raycaster.setFromCamera(mouse, camera); const h = raycaster.intersectObjects(allMeshes); setHovered(h.length ? h[0].object.userData : null); };
    const onClick = (e) => { getNDC(e); raycaster.setFromCamera(mouse, camera); const h = raycaster.intersectObjects(allMeshes); if (h.length && onRoomClick) onRoomClick(h[0].object.userData.room_id); };
    renderer.domElement.addEventListener("mousemove", onMove);
    renderer.domElement.addEventListener("click",     onClick);

    // ── 드래그 회전 ─────────────────────────────────
    let dragging = false, lastX = 0, lastY = 0;
    let azimuth = 0.6, elevation = 0.4;
    const R = 36;
    const updateCam = () => {
      camera.position.set(
        Math.sin(azimuth) * R * Math.cos(elevation) + 5,
        Math.sin(elevation) * R + 4,
        Math.cos(azimuth) * R * Math.cos(elevation) + 2
      );
      camera.lookAt(5, 4, 2);
    };
    const onDown = (e) => { dragging = true; lastX = e.clientX; lastY = e.clientY; };
    const onUp   = () => { dragging = false; };
    const onDrag = (e) => {
      if (!dragging) return;
      azimuth   += (e.clientX - lastX) * 0.007;
      elevation -= (e.clientY - lastY) * 0.005;
      elevation  = Math.max(0.05, Math.min(1.1, elevation));
      lastX = e.clientX; lastY = e.clientY;
      updateCam();
    };
    renderer.domElement.addEventListener("mousedown", onDown);
    window.addEventListener("mouseup",   onUp);
    window.addEventListener("mousemove", onDrag);

    // ── 렌더 루프 ────────────────────────────────────
    let t = 0;
    const animate = () => {
      frameRef.current = requestAnimationFrame(animate);
      t += 0.05;
      Object.values(meshMap).forEach(m => {
        const hex = m.material.color.getHex();
        // 화재: 빠른 점멸
        if (hex === ALERT_COLOR["fire"]) {
          m.material.opacity = 0.6 + Math.abs(Math.sin(t * 8)) * 0.35;
        }
        // 흡연: 느린 점멸
        else if (hex === ALERT_COLOR["smoke"]) {
          m.material.opacity = 0.5 + Math.abs(Math.sin(t * 3)) * 0.3;
        }
        // 위험 상태
        else if (hex === STATUS_COLOR["위험"]) {
          m.material.opacity = 0.55 + Math.sin(t * 5) * 0.3;
        }
      });
      renderer.render(scene, camera);
    };
    
    animate();

    const onResize = () => {
      if (!mountRef.current) return;
      const W2 = mountRef.current.clientWidth;
      const H2 = mountRef.current.clientHeight;
      camera.aspect = W2 / H2; camera.updateProjectionMatrix();
      renderer.setSize(W2, H2);
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(frameRef.current);
      renderer.domElement.removeEventListener("mousemove", onMove);
      renderer.domElement.removeEventListener("click",     onClick);
      renderer.domElement.removeEventListener("mousedown", onDown);
      window.removeEventListener("mouseup",    onUp);
      window.removeEventListener("mousemove",  onDrag);
      window.removeEventListener("resize",     onResize);
      renderer.dispose();
      if (mountRef.current) mountRef.current.innerHTML = "";
    };
  }, [rooms.length]);


  // ── 실시간 색상 + 경보 레이블 업데이트 ─────────────
  useEffect(() => {
    rooms.forEach(room => {
      const mesh   = meshMapRef.current[room.room_id];
      const sprite = labelMapRef.current[room.room_id];
      if (!mesh) return;

      const alertType = alertMap[room.room_id];

      if (alertType === "fire") {
        mesh.material.color.setHex(ALERT_COLOR["fire"]);
        mesh.material.opacity = 0.9;
        if (sprite) { sprite.visible = true; _updateSprite(sprite, "🔥 화재!", "#ff2200"); }
      } else if (alertType === "smoke") {
        mesh.material.color.setHex(ALERT_COLOR["smoke"]);
        mesh.material.opacity = 0.8;
        if (sprite) { sprite.visible = true; _updateSprite(sprite, "🚬 흡연감지", "#ff8800"); }
      } else {
        const color   = STATUS_COLOR[room.status]   ?? STATUS_COLOR["정상"];
        const opacity = STATUS_OPACITY[room.status] ?? STATUS_OPACITY["정상"];
        mesh.material.color.setHex(color);
        if (room.status !== "위험") mesh.material.opacity = opacity;
        if (sprite) sprite.visible = false;
      }

      // 선택 강조
      mesh.material.emissive?.setHex(room.room_id === selectedRoomId ? 0x3355aa : 0x000000);

    });
  }, [rooms, selectedRoomId, alertRooms]);

  return (
    <div style={{ position: "relative", width: "100%", height: "100%" }}>
      <div ref={mountRef} style={{ width: "100%", height: "100%", cursor: "grab" }} />

      {hovered && (
        <div style={{
          position: "absolute", bottom: 14, left: 14,
          background: "rgba(10,12,20,0.9)", border: "1px solid #334",
          borderRadius: 6, padding: "4px 10px", fontSize: 11, color: "#ccc",
          pointerEvents: "none",
        }}>
          {hovered.name}
          {alertMap[hovered.room_id] === "fire"  && " 🔥 화재 경보"}
          {alertMap[hovered.room_id] === "smoke" && " 🚬 흡연 감지"}
          {" — 클릭하여 선택"}
        </div>
      )}

      {/* 범례 */}
      <div style={{
        position: "absolute", top: 10, right: 10,
        background: "rgba(10,12,20,0.85)", border: "1px solid #334",
        borderRadius: 6, padding: "8px 12px",
        display: "flex", flexDirection: "column", gap: 4, fontSize: 11,
      }}>
        {[
          ["정상",    "#1D9E75"],
          ["경고",    "#EF9F27"],
          ["위험",    "#E24B4A"],
          ["화재",    "#FF2200"],
          ["흡연감지","#ffee00"],
        ].map(([label, color]) => (
          <span key={label} style={{ display: "flex", alignItems: "center", gap: 6, color: "#aaa" }}>
            <span style={{ width: 10, height: 10, borderRadius: 2, background: color, display: "inline-block" }} />
            {label}
          </span>
        ))}
        <span style={{ color: "#fff", marginTop: 2, fontSize: 10 }}>드래그: 회전</span>
      </div>
    </div>
  );
}

// ── 스프라이트 유틸 ───────────────────────────────────
function _makeAlertSprite(text) {
  const canvas = document.createElement("canvas");
  canvas.width = 256; canvas.height = 64;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "rgba(0,0,0,0)";
  ctx.fillRect(0, 0, 256, 64);
  const tex = new THREE.CanvasTexture(canvas);
  const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false });
  const sprite = new THREE.Sprite(mat);
  sprite.scale.set(3, 0.8, 1);
  sprite._canvas = canvas;
  sprite._ctx    = ctx;
  return sprite;
}

function _updateSprite(sprite, text, color) {
  const canvas = sprite._canvas;
  const ctx    = sprite._ctx;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "rgba(0,0,0,0.75)";
  roundRect(ctx, 4, 4, canvas.width - 8, canvas.height - 8, 8);
  ctx.fill();
  ctx.fillStyle = color;
  ctx.font = "bold 22px sans-serif";
  ctx.textAlign = "center";
  ctx.fillText(text, canvas.width / 2, canvas.height / 2 + 8);
  sprite.material.map.needsUpdate = true;
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y); ctx.arcTo(x + w, y, x + w, y + r, r);
  ctx.lineTo(x + w, y + h - r); ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
  ctx.lineTo(x + r, y + h); ctx.arcTo(x, y + h, x, y + h - r, r);
  ctx.lineTo(x, y + r); ctx.arcTo(x, y, x + r, y, r);
  ctx.closePath();
}