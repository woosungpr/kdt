/**
 * 5개 공간 카메라 그리드 패널
 * - 각 공간별 실시간 영상 (WebSocket 10fps)
 * - 화재/흡연 감지 시 테두리 점멸 + 음성 경보
 * - 공간 선택 후 개별 트리거 버튼
 */
import { useEffect, useRef, useState } from "react";

const API = "http://127.0.0.1:8000";
const WS_CAM = "ws://127.0.0.1:8000/ws/cameras";

// ── 음성 경보 ─────────────────────────────────────────
let lastSpeakTime = {};
function speak(roomId, type, roomLabel) {
  if (!window.speechSynthesis) return;
  const now = Date.now();
  const key = `${roomId}-${type}`;
  if (now - (lastSpeakTime[key] || 0) < 5000) return;
  lastSpeakTime[key] = now;
  window.speechSynthesis.cancel();
  const msg = type === "fire"
    ? `경고! ${roomLabel}에서 화재가 감지되었습니다. 즉시 대피하세요.`
    : `${roomLabel}에서 흡연이 감지되었습니다. 확인이 필요합니다.`;
  const utt = new SpeechSynthesisUtterance(msg);
  utt.lang = "ko-KR"; utt.rate = 1.1; utt.volume = 1.0;
  window.speechSynthesis.speak(utt);
}

// ── 경보음 (Web Audio API) ────────────────────────────
let audioCtx = null;
function playBeep(type) {
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const osc  = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain); gain.connect(audioCtx.destination);
    osc.frequency.value = type === "fire" ? 880 : 660;
    osc.type = "square";
    gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.4);
    osc.start(); osc.stop(audioCtx.currentTime + 0.4);
  } catch (_) {}
}

const ROOM_ORDER = ["r-101", "r-201", "r-202", "r-301", "r-302"];
const ROOM_NAMES = {
  "r-101": "로비", "r-201": "사무공간 A", "r-202": "회의실 1",
  "r-301": "사무공간 B", "r-302": "서버실",
};

export default function FireCameraPanel({ rooms, selectedRoom, setSelectedRoom, threeRef }) {
  const [frames,      setFrames]      = useState({});
  const [alerts,      setAlerts]      = useState([]);
  const [wsStatus,    setWsStatus]    = useState("연결 중");
  // const [selectedRoom, setSelectedRoom] = useState("r-101");
  const [alertLog,    setAlertLog]    = useState([]);
  const lastBeepRef = useRef({});

  // ── WebSocket 연결 ─────────────────────────────────
  useEffect(() => {
    let ws, retryTimer, stopped = false;
    const connect = () => {
      if (stopped) return;
      ws = new WebSocket(WS_CAM);
      ws.onopen  = () => setWsStatus("연결됨");
      ws.onclose = () => { setWsStatus("재연결 중"); if (!stopped) retryTimer = setTimeout(connect, 2000); };
      ws.onerror = () => ws.close();
      ws.onmessage = (e) => {
        const data = JSON.parse(e.data);
        setFrames(data.frames || {});
        setAlerts(data.alerts || []);

        // 경보 처리
        (data.alerts || []).forEach(a => {
          const key = `${a.room_id}-${a.alert_type}`;
          const now = Date.now();
          if (now - (lastBeepRef.current[key] || 0) > 4000) {
            lastBeepRef.current[key] = now;
            playBeep(a.alert_type);
            speak(a.room_id, a.alert_type, a.room_label);
            setAlertLog(prev => [
              { ...a, time: new Date().toLocaleTimeString() },
              ...prev.slice(0, 9),
            ]);
          }
        });
      };
    };
    setTimeout(connect, 400);
    return () => { stopped = true; clearTimeout(retryTimer); ws?.close(); };
  }, []);

  // ── 트리거 함수 ────────────────────────────────────
  const triggerFire = async (rid) => {
    await fetch(`${API}/api/trigger/fire`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ room_id: rid, x_ratio: 0.5, y_ratio: 0.75 }),
    });
  };
  const stopFire = async (rid) => {
    await fetch(`${API}/api/trigger/fire/stop`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ room_id: rid }),
    });
  };
  const triggerSmoke = async (rid) => {
    await fetch(`${API}/api/trigger/smoking`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ room_id: rid, duration: 180 }),
    });
  };
  const stopSmoke = async (rid) => {
    await fetch(`${API}/api/trigger/smoking/stop`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ room_id: rid }),
    });
  };

  const alertRoomIds = new Set(alerts.map(a => a.room_id));
  const alertTypeMap = Object.fromEntries(alerts.map(a => [a.room_id, a.alert_type]));

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10, padding: 12, height: "100%", overflowY: "auto", background: "#f4f6fb" }}>

      {/* 헤더 */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{
          fontSize: 12,
          fontWeight: 600,
          color: "#1F2937"
        }}>
          🔥화재 🚬흡연 감시 카메라 (5개 공간)
        </span>
        <span style={{ fontSize: 10, color: wsStatus === "연결됨" ? "#1D9E75" : "#E24B4A" }}>
          {wsStatus}
        </span>
      </div>

      {/* 경보 배너 */}
      {alerts.length > 0 && (
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          {alerts.map(a => (
            <div key={a.room_id} style={{
              padding: "6px 10px", borderRadius: 6, fontSize: 11, fontWeight: 600,
              background: a.alert_type === "fire" ? "#3a0a0a" : "#1e1208",
              border: `1px solid ${a.alert_type === "fire" ? "#E24B4A" : "#EF9F27"}`,
              color: a.alert_type === "fire" ? "#E24B4A" : "#EF9F27",
              animation: "blink 0.8s ease-in-out infinite alternate",
            }}>
              {a.alert_type === "fire" ? "🔥 화재" : "🚬 흡연"} — {a.room_label}
            </div>
          ))}
        </div>
      )}

      {/* 5개 카메라 그리드 */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 6,
      }}>
        {ROOM_ORDER.map(rid => {
          const frameData = frames[rid];
          const isAlert   = alertRoomIds.has(rid);
          const aType     = alertTypeMap[rid];
          const borderColor = aType === "fire" ? "#E24B4A"
            : aType === "smoke" ? "#EF9F27" : "#2a2d3a";
          const isSelected = selectedRoom === rid;

          return (
            <div
              key={rid}
              onClick={() => {
                setSelectedRoom(rid);

                setTimeout(() => {
                  threeRef?.current?.scrollIntoView({
                    behavior: "smooth",
                    block: "center"
                  });
                }, 50);
              }}
              style={{
                position: "relative", cursor: "pointer",
                borderRadius: 6, overflow: "hidden",
                border: `3px solid ${isSelected ? "#7C3AED" : borderColor}`,
                boxShadow: isSelected ? "0 0 10px #7C3AED" : "none",
                aspectRatio: "4/3", background: "#e9edf5",
                animation: isAlert ? "border-pulse 0.5s ease-in-out infinite alternate" : "none",
              }}
            >
              {frameData?.frame ? (
                <img
                  src={`data:image/jpeg;base64,${frameData.frame}`}
                  style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }}
                  alt={ROOM_NAMES[rid]}
                />
              ) : (
                <div style={{ display: "flex", alignItems: "center", justifyContent: "center",
                  height: "100%", color: "#334", fontSize: 10 }}>
                  {ROOM_NAMES[rid]}
                </div>
              )}

              {/* 공간명 배치 */}
              <div style={{
                position: "absolute", bottom: 3, left: 3,
                background: "rgba(0,0,0,0.7)", borderRadius: 3,
                padding: "2px 5px", fontSize: 9, color: "#fff",
              }}>
                {ROOM_NAMES[rid]}
              </div>

              {/* 경보 아이콘 */}
              {isAlert && (
                <div style={{
                  position: "absolute", top: 3, right: 3,
                  fontSize: 14,
                }}>
                  {aType === "fire" ? "🔥" : "🚬"}
                </div>
              )}
            </div>
          );
        })}

        {/* 5번째 셀이 그리드 2열이면 마지막 빈칸 채우기용 — 이미 5개라 OK */}
      </div>

      {/* 선택 공간 컨트롤 */}
      <div style={{
        background: "#ffffff", borderRadius: 8, padding: "10px 12px",
        border: "1px solid #2a2d3a", boxShadow: "0 2px 6px rgba(0,0,0,0.08)"
      }}>
        <div style={{ fontSize: 11, color: "#000", marginBottom: 8 }}>
          선택: <span style={{ color: "#0000ff", fontWeight: 600 }}>
            {ROOM_NAMES[selectedRoom]}
          </span>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
          <button onClick={() => triggerFire(selectedRoom)} style={btnStyle("#7B1F1F", "#ffaaaa")}>
            화재 발생
          </button>
          <button onClick={() => stopFire(selectedRoom)} style={btnStyle("#1a2a1a", "#88bb88")}>
            화재 진압
          </button>
          <button onClick={() => triggerSmoke(selectedRoom)} style={btnStyle("#2a1a00", "#EF9F27")}>
            흡연 발생
          </button>
          <button onClick={() => stopSmoke(selectedRoom)} style={btnStyle("#1a1a2a", "#aaaaee")}>
            흡연 종료
          </button>
        </div>
      </div>

      {/* 경보 로그 */}
      {alertLog.length > 0 && (
        <div style={{ background: "#ffffff", borderRadius: 8, padding: "8px 10px", border: "1px solid #2a2d3a" }}>
          <div style={{ fontSize: 10, color: "#445", marginBottom: 5 }}>경보 이력</div>
          {alertLog.map((a, i) => (
            <div key={i} style={{
              fontSize: 10, color: a.alert_type === "fire" ? "#E24B4A99" : "#EF9F2799",
              padding: "2px 0", borderBottom: "1px solid #1e2130",
            }}>
              {a.time} — {a.alert_type === "fire" ? "화재" : "흡연"} / {a.room_label}
            </div>
          ))}
        </div>
      )}

      <style>{`
        @keyframes blink { from { opacity: 1; } to { opacity: 0.4; } }
        @keyframes border-pulse { from { box-shadow: 0 0 0 0 rgba(226,75,74,0.6); } to { box-shadow: 0 0 8px 2px rgba(226,75,74,0.2); } }
      `}</style>
    </div>
  );
}

function btnStyle(bg, color) {
  return {
    padding: "7px 0", borderRadius: 6, border: "none",
    background: bg, color, fontSize: 11, fontWeight: 600, cursor: "pointer",
  };
}