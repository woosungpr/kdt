/**
 * 공간 상세 패널 - 센서 게이지 + 추이 차트 + AI 분석 결과
 * RoomDetailPanel - ML 앙상블 분석 결과 표시
 * 
 * 추가 기능:
 * 1. ML 실시간 이상 탐지 결과 표시
 * 2. 센서별 이상 확률 표시
 * 3. 앙상블 모델 신뢰도 표시 (XGBoost + RF + LR)
 */
import { LineChart, Line, XAxis, YAxis, Tooltip, ReferenceLine, ResponsiveContainer } from "recharts";

const SEV_COLOR = { "위험": "#E24B4A", "경고": "#EF9F27", "정상": "#1D9E75" };
const API = "";  // App.jsx와 동일하게

// 🎮 센서 시나리오 발생 함수 
const triggerSensorAnomaly = async (roomId, anomalyType, severity) => {
  try {
    let endpoint = "/api/trigger/anomaly";
    let body = {
      room_id: roomId,
      anomaly_type: anomalyType,
      severity: severity,
      duration: 60,
    };

    // 복합 경보 엔드포인트
    if (anomalyType === "multi") {
      endpoint = "/api/trigger/multi-anomalies";
      body.severity = severity;
      delete body.anomaly_type;
    }

    const res = await fetch(`${API}${endpoint}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    // let data;
    // try {
    //   data = await res.json();
    // } catch (e) {
    //   const text = await res.text();
    //   console.error("서버 JSON 아님:", text);
    //   throw new Error(text);
    // }
    // if (!res.ok) {
    //   throw new Error(data?.message || "서버 오류");
    // }
    // console.log("센서 시나리오 발생:", data);

  } catch (e) {
    console.error("센서 시나리오 발생 실패:", e);
    alert("센서 시나리오 발생 실패");
  }
};

// export function RoomDetailPanel({ roomData, history, aiResult, onAnalyze, analyzing }) {
export function RoomDetailPanel({ roomData, history, aiResult, onAnalyze, analyzing, mlAnomaly }) {
  if (!roomData) return (
    <div style={{ padding: 24, color: "#fff", fontSize: 13, lineHeight: 1.8 }}>
      3D 뷰에서 공간을 클릭하면 상세 정보가 표시됩니다.
    </div>
  );

  const { name, floor, zone, readings, status, occupancy_estimate, sensors_meta, room_id } = roomData;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14, padding: 14, overflowY: "auto" }}>

      {/* 헤더 */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div>
          <div style={{ fontSize: 15, fontWeight: 600, color: "#e8e6de" }}>{name}</div>
          <div style={{ fontSize: 11, color: "#9ecbff", marginTop: 2 }}>
            {floor}층 · {zone} · 재실 추정 <span style={{ color: "#fff", fontWeight: 600 }}>
                                            {occupancy_estimate}
                                          </span>명
          </div>
        </div>
        <span style={{
          padding: "3px 10px", borderRadius: 12, fontSize: 11, fontWeight: 600,
          background: SEV_COLOR[status] + "33", color: SEV_COLOR[status],
          border: `1px solid ${SEV_COLOR[status]}55`,
        }}>{status}</span>
      </div>

      {/* 센서 게이지 그리드 */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
        {readings && sensors_meta && Object.entries(readings).map(([stype, val]) => {
          const meta = sensors_meta[stype];
          if (!meta) return null;
          const range = meta.critical_threshold - meta.normal_min;
          const ratio = Math.min(Math.max((val - meta.normal_min) / range, 0), 1);
          const color = val >= meta.critical_threshold ? "#E24B4A"
            : val >= meta.warning_threshold ? "#EF9F27"
            : "#1D9E75";

          const baseColor =
            stype === "temperature" ? "#ff6b6b" :
            stype === "humidity"    ? "#4dabf7" :
            stype === "noise"       ? "#ffd43b" :
            "#fff";

          const finalColor =
            val >= meta.critical_threshold ? "#E24B4A"
            : val >= meta.warning_threshold ? "#EF9F27"
            : baseColor;

          return (
            <div key={stype} style={{
              background: "#151820", borderRadius: 8, padding: "10px 12px",
              border: "1px solid #2a2d3a",
            }}>
              <div style={{ fontSize: 10, color:  finalColor , marginBottom: 4 }}>{meta.description}</div>
              <div style={{ fontSize: 22, fontWeight: 600, color, marginBottom: 6 }}>
                {val}
                <span style={{ fontSize: 11, marginLeft: 2, fontWeight: 400, color: "#fff" }}>{meta.unit}</span>
              </div>
              <div style={{ height: 3, background: "#2a2d3a", borderRadius: 2 }}>
                <div style={{
                  width: `${ratio * 100}%`, height: "100%",
                  background: color, borderRadius: 2,
                  transition: "width 0.6s ease",
                }} />
              </div>
              <div style={{ fontSize: 10, color: "#fff", marginTop: 3 }}>
                정상 {meta.normal_min}–{meta.normal_max}{meta.unit}
              </div>
            </div>
          );
        })}
      </div>

     {/* ?? ML 실시간 이상 탐지 결과 표시 */}
      {mlAnomaly && (
        <div style={{
          background: "#151820",
          border: `1px solid ${mlAnomaly.overall_status === "위험" ? "#E24B4A44" : "#EF9F2744"}`,
          borderRadius: 8,
          padding: "10px 12px",
        }}>
          <div style={{
            fontSize: 11,
            fontWeight: 700,
            color: "#fff",
            marginBottom: 8,
            textTransform: "uppercase",
            letterSpacing: 0.5,
          }}>
            🤖 ML 앙상블 분석 (실시간)
          </div>

          {/* 종합 상태 */}
          <div style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 8,
            padding: "6px 0",
            borderBottom: "1px solid #2a2d3a",
          }}>
            <span style={{ fontSize: 11, color: "#fff" }}>종합 상태</span>
            <span style={{
              fontSize: 12,
              fontWeight: 700,
              color: SEV_COLOR[mlAnomaly.overall_status] || "#378ADD",
            }}>
              {mlAnomaly.overall_status}
            </span>
          </div>

          {/* 위험도 바 */}
          <div style={{ marginBottom: 8 }}>
            <div style={{ fontSize: 10, color: "#fff", marginBottom: 3 }}>
              위험도: {mlAnomaly.risk_level}/2
            </div>
            <div style={{ height: 4, background: "#2a2d3a", borderRadius: 2, overflow: "hidden" }}>
              <div style={{
                width: `${(mlAnomaly.risk_level / 2) * 100}%`,
                height: "100%",
                background: mlAnomaly.risk_level === 0 ? "#1D9E75" 
                  : mlAnomaly.risk_level === 1 ? "#EF9F27"
                  : "#E24B4A",
                transition: "width 0.3s",
              }} />
            </div>
          </div>

          {/* 센서별 이상 확률 */}
          {mlAnomaly.sensors && mlAnomaly.sensors.length > 0 && (
            <div style={{ fontSize: 10, color: "#aaa" }}>
              <div style={{ marginBottom: 4, fontWeight: 600, color: "#fff" }}>이상 확률:</div>
              {mlAnomaly.sensors.map((sensor, i) => (
                <div key={i} style={{
                  display: "flex",
                  justifyContent: "space-between",
                  padding: "4px 0",
                  borderBottom: i < mlAnomaly.sensors.length - 1 ? "1px solid #2a2d3a" : "none",
                }}>
                  <span style={{ color: sensor.is_abnormal ? "#E24B4A" : "#fff" }}>
                    {sensor.sensor}
                  </span>
                  <span style={{
                    color: sensor.abnormal_prob >= 0.7 ? "#E24B4A"
                      : sensor.abnormal_prob >= 0.5 ? "#EF9F27"
                      : "#1D9E75",
                    fontWeight: 600,
                  }}>
                    {(sensor.abnormal_prob * 100).toFixed(0)}%
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* 신뢰도 정보 */}
          {mlAnomaly.sensors && mlAnomaly.sensors.length > 0 && (
            <div style={{
              fontSize: 9,
              color: "#fff",
              marginTop: 6,
              padding: "4px 6px",
              background: "#0f1219",
              borderRadius: 4,
            }}>
              🔍 모델: XGBoost(3) + RandomForest(2) + LogisticRegression(1) Voting
            </div>
          )}
        </div>
      )}

      {/* CO₂ 추이 차트 */}
      {history && history.length > 5 && (() => {
        const meta = roomData.sensors_meta?.co2;
        const chartData = history.slice(-60).map((h, i) => ({
          t: i, co2: h.readings?.co2, temp: h.readings?.temperature,
        }));
        return (
          <div style={{ background: "#151820", borderRadius: 8, padding: "10px 12px", border: "1px solid #2a2d3a" }}>
            <div style={{ fontSize: 10, color: "#fff", marginBottom: 6 }}>CO₂ 추이 (최근 60초)</div>
            <ResponsiveContainer width="100%" height={90}>
              <LineChart data={chartData}>
                <XAxis dataKey="t" hide />
                <YAxis domain={["auto", "auto"]} width={38}
                  tick={{ fontSize: 9, fill: "#fff" }} tickLine={false} axisLine={false} />
                <Tooltip
                  contentStyle={{ background: "#1a1d26", border: "1px solid #334", fontSize: 11 }}
                  labelStyle={{ color: "#667" }}
                  itemStyle={{ color: "#aaa" }}
                  formatter={v => [`${v} ppm`, "CO₂"]}
                  labelFormatter={() => ""}
                />
                {meta && <>
                  <ReferenceLine y={meta.warning_threshold}  stroke="#EF9F27" strokeDasharray="3 2" strokeWidth={0.8} />
                  <ReferenceLine y={meta.critical_threshold} stroke="#E24B4A" strokeDasharray="3 2" strokeWidth={0.8} />
                </>}
                <Line type="monotone" dataKey="co2" stroke="#378ADD"
                  dot={false} strokeWidth={1.5} isAnimationActive={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        );
      })()}


      {/* 🎮 센서 시나리오 버튼 섹션 (새로 추가) */}
      <div style={{
        background: "#151820",
        border: "1px solid #2a2d3a",
        borderRadius: 8,
        padding: "12px",
      }}>
        <div style={{
          fontSize: 11,
          fontWeight: 700,
          color: "#fff",
          marginBottom: 10,
          textTransform: "uppercase",
          letterSpacing: 0.5,
        }}>
          🎮 센서 시나리오 시연
        </div>

        {/* 온도 버튼 */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 6, marginBottom: 8 }}>
          <button
            onClick={() => triggerSensorAnomaly(room_id, "temperature", "warning")}
            style={{
              flex: 1,
              padding: "6px 8px",
              borderRadius: 4,
              border: "1px solid #fed7aa",
              background: "#fef3c7",
              color: "#92400e",
              fontSize: 11,
              fontWeight: 600,
              cursor: "pointer",
              transition: "all 0.2s",
            }}
            onMouseEnter={e => {
              e.target.style.background = "#fde68a";
              e.target.style.transform = "scale(1.02)";
            }}
            onMouseLeave={e => {
              e.target.style.background = "#fef3c7";
              e.target.style.transform = "scale(1)";
            }}
          >
             🌡️ 과열 경고
          </button>
          <button
            onClick={() => triggerSensorAnomaly(room_id, "temperature", "critical")}
            style={{
              flex: 1,
              padding: "6px 8px",
              borderRadius: 4,
              border: "1px solid #fecaca",
              background: "#fee2e2",
              color: "#991b1b",
              fontSize: 11,
              fontWeight: 600,
              cursor: "pointer",
              transition: "all 0.2s",
            }}
            onMouseEnter={e => {
              e.target.style.background = "#fca5a5";
              e.target.style.transform = "scale(1.02)";
            }}
            onMouseLeave={e => {
              e.target.style.background = "#fee2e2";
              e.target.style.transform = "scale(1)";
            }}
          >
             🌡️ 과열 심각
          </button>
        {/* 습도 버튼 */}
          <button
            onClick={() => triggerSensorAnomaly(room_id, "humidity", "warning")}
            style={{
              flex: 1,
              padding: "6px 8px",
              borderRadius: 4,
              border: "1px solid #cffafe",
              background: "#ecf9ff",
              color: "#0c4a6e",
              fontSize: 11,
              fontWeight: 600,
              cursor: "pointer",
              transition: "all 0.2s",
            }}
            onMouseEnter={e => {
              e.target.style.background = "#a5f3fc";
              e.target.style.transform = "scale(1.02)";
            }}
            onMouseLeave={e => {
              e.target.style.background = "#ecf9ff";
              e.target.style.transform = "scale(1)";
            }}
          >
            💧 습도 경고
          </button>
          <button
            onClick={() => triggerSensorAnomaly(room_id, "humidity", "critical")}
            style={{
              flex: 1,
              padding: "6px 8px",
              borderRadius: 4,
              border: "1px solid #86efac",
              background: "#dcfce7",
              color: "#166534",
              fontSize: 11,
              fontWeight: 600,
              cursor: "pointer",
              transition: "all 0.2s",
            }}
            onMouseEnter={e => {
              e.target.style.background = "#86efac";
              e.target.style.transform = "scale(1.02)";
            }}
            onMouseLeave={e => {
              e.target.style.background = "#dcfce7";
              e.target.style.transform = "scale(1)";
            }}
          >
            💧 습도 심각
          </button>
        </div>

        {/* CO2 버튼 */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 6, marginBottom: 8 }}>
          <button
            onClick={() => triggerSensorAnomaly(room_id, "co2", "warning")}
            style={{
              flex: 1,
              padding: "6px 8px",
              borderRadius: 4,
              border: "1px solid #d1d5db",
              background: "#f3f4f6",
              color: "#374151",
              fontSize: 11,
              fontWeight: 600,
              cursor: "pointer",
              transition: "all 0.2s",
            }}
            onMouseEnter={e => {
              e.target.style.background = "#e5e7eb";
              e.target.style.transform = "scale(1.02)";
            }}
            onMouseLeave={e => {
              e.target.style.background = "#f3f4f6";
              e.target.style.transform = "scale(1)";
            }}
          >
            🌫️ CO2 경고
          </button>
          <button
            onClick={() => triggerSensorAnomaly(room_id, "co2", "critical")}
            style={{
              flex: 1,
              padding: "6px 8px",
              borderRadius: 4,
              border: "1px solid #94a3b8",
              background: "#e2e8f0",
              color: "#0f172a",
              fontSize: 11,
              fontWeight: 600,
              cursor: "pointer",
              transition: "all 0.2s",
            }}
            onMouseEnter={e => {
              e.target.style.background = "#cbd5e1";
              e.target.style.transform = "scale(1.02)";
            }}
            onMouseLeave={e => {
              e.target.style.background = "#e2e8f0";
              e.target.style.transform = "scale(1)";
            }}
          >
            🌫️ CO2 심각
          </button>
        {/* PM2.5 버튼 */}
          <button
            onClick={() => triggerSensorAnomaly(room_id, "pm25", "warning")}
            style={{
              flex: 1,
              padding: "6px 8px",
              borderRadius: 4,
              border: "1px solid #fde68a",
              background: "#fffacd",
              color: "#a16207",
              fontSize: 11,
              fontWeight: 600,
              cursor: "pointer",
              transition: "all 0.2s",
            }}
            onMouseEnter={e => {
              e.target.style.background = "#fde047";
              e.target.style.transform = "scale(1.02)";
            }}
            onMouseLeave={e => {
              e.target.style.background = "#fffacd";
              e.target.style.transform = "scale(1)";
            }}
          >
            🌪️ 미세먼지 경고
          </button>
          <button
            onClick={() => triggerSensorAnomaly(room_id, "pm25", "critical")}
            style={{
              flex: 1,
              padding: "6px 8px",
              borderRadius: 4,
              border: "1px solid #fb923c",
              background: "#fed7aa",
              color: "#7c2d12",
              fontSize: 11,
              fontWeight: 600,
              cursor: "pointer",
              transition: "all 0.2s",
            }}
            onMouseEnter={e => {
              e.target.style.background = "#fb923c";
              e.target.style.transform = "scale(1.02)";
            }}
            onMouseLeave={e => {
              e.target.style.background = "#fed7aa";
              e.target.style.transform = "scale(1)";
            }}
          >
            🌪️ 미세먼지 심각
          </button>
        </div>

        {/* 복합 경보 버튼 */}
        <button
          onClick={() => triggerSensorAnomaly(room_id, "multi", "critical")}
          style={{
            width: "100%",
            padding: "8px 12px",
            borderRadius: 4,
            border: "2px solid #dc2626",
            background: "#fca5a5",
            color: "#7f1d1d",
            fontSize: 12,
            fontWeight: 700,
            cursor: "pointer",
            marginBottom: 6,
            boxShadow: "0 2px 4px rgba(220,38,38,0.3)",
            transition: "all 0.2s",
          }}
          onMouseEnter={e => {
            e.target.style.background = "#ef4444";
            e.target.style.color = "#fff";
            e.target.style.transform = "scale(1.02)";
          }}
          onMouseLeave={e => {
            e.target.style.background = "#fca5a5";
            e.target.style.color = "#7f1d1d";
            e.target.style.transform = "scale(1)";
          }}
        >
          🚨 복합 경보 (온도 + CO2)
        </button>

        {/* 정상화 버튼 */}
        <button
          onClick={() => triggerSensorAnomaly(room_id, "normal", "warning")}
          style={{
            width: "100%",
            padding: "8px 12px",
            borderRadius: 4,
            border: "1px solid #10b981",
            background: "#d1fae5",
            color: "#065f46",
            fontSize: 11,
            fontWeight: 600,
            cursor: "pointer",
            transition: "all 0.2s",
          }}
          onMouseEnter={e => {
            e.target.style.background = "#a7f3d0";
            e.target.style.transform = "scale(1.02)";
          }}
          onMouseLeave={e => {
            e.target.style.background = "#d1fae5";
            e.target.style.transform = "scale(1)";
          }}
        >
          ✅ 모든 시나리오 종료
        </button>
      </div>



      {/* AI 분석 버튼 */}
      <button onClick={onAnalyze} disabled={analyzing} style={{
        padding: "9px 0", borderRadius: 8, border: "none", cursor: analyzing ? "default" : "pointer",
        background: analyzing ? "#2a2d3a" : "#534AB7",
        color: analyzing ? "#fff" : "#EEEDFE",
        fontSize: 13, fontWeight: 600, letterSpacing: 0.3,
        transition: "background 0.2s",
      }}>
        {/* {analyzing ? "GPT 분석 중..." : "AI 이상 분석 실행 (GPT)"} */}
         {analyzing ? "AI + ML 분석 중..." : "AI + ML 종합 분석 실행"}
      </button>

      {/* AI 분석 결과 카드 */}
      {aiResult && (
        <>
          {console.log("aiResult:", aiResult)}
          <AIResultCard result={aiResult} />
        </>
      )}
    </div>
  );
}

function AIResultCard({ result }) {
  const a  = result.ai_analysis;
  const wo = result.work_order;
  // const c  = SEV_COLOR[a?.severity] ?? "#378ADD";
  const c  = { "위험": "#E24B4A", "경고": "#EF9F27", "정상": "#1D9E75" }[a?.severity] ?? "#378ADD";

  return (
    <div style={{ border: `1px solid ${c}44`, borderRadius: 8, overflow: "hidden" }}>
      {/* 헤더 */}
      <div style={{
        padding: "7px 12px", background: c + "18",
        borderBottom: `1px solid ${c}33`,
        display: "flex", justifyContent: "space-between", alignItems: "center",
      }}>
        <span style={{ fontSize: 12, fontWeight: 600, color: c }}>
          {a?.severity} — AI + ML 분석 결과
        </span>
        <span style={{ fontSize: 10, color: "#667" }}>신뢰도 {a?.confidence}%</span>
      </div>

      <div style={{ padding: 12, display: "flex", flexDirection: "column", gap: 10 }}>
        {/* 원인 */}
        <div>
          <div style={{ fontSize: 10, color: "#556", marginBottom: 3 }}>원인 분석</div>
          <div style={{ fontSize: 12, color: "#bbb", lineHeight: 1.6 }}>{a?.cause}</div>
        </div>

        {/* 조치 */}
        <div>
          <div style={{ fontSize: 10, color: "#556", marginBottom: 4 }}>조치 사항</div>
          {a?.actions?.map((action, i) => (
            <div key={i} style={{
              fontSize: 11, color: "#9ab", padding: "3px 0",
              borderBottom: "1px solid #1e2130",
            }}>
              {i + 1}. {action}
            </div>
          ))}
        </div>

        {/* 방치 시 위험 */}
        {a?.predicted_risk && (
          <div style={{
            background: "#2a1a1a", border: "1px solid #E24B4A33",
            borderRadius: 6, padding: "6px 10px",
            fontSize: 11, color: "#E24B4A99",
          }}>
            방치 시: {a.predicted_risk}
          </div>
        )}

        {/* 작업지시서 */}
        {wo && (
          <div style={{
            background: "#151820", border: "1px solid #2a2d3a",
            borderRadius: 6, padding: "7px 10px",
          }}>
            <div style={{ fontSize: 10, color: "#556", marginBottom: 4 }}>자동 생성 작업지시서</div>
            <div style={{ fontSize: 11, color: "#778" }}>
              #{wo.work_order_id} · <span style={{ color: wo.priority === "긴급" ? "#E24B4A" : "#EF9F27" }}>
                {wo.priority}
              </span> · {wo.assigned_to}
            </div>
            <div style={{ fontSize: 10, color: "#445", marginTop: 2 }}>
              발행: {wo.issued_at} · 처리기한: {wo.due_time}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
