"""
디지털 트윈 핵심 모델
실내 공간(Room)과 가상 센서(Sensor)를 파이썬 클래스로 추상화.
이것이 '디지털 트윈의 가상 모델(Virtual Model)' 역할을 합니다.
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from datetime import datetime
import time


@dataclass
class SensorSpec:
    """가상 센서 사양 정의 - 실제 IoT 센서 없이 소프트웨어로 정의"""
    sensor_id: str
    sensor_type: str        # "temperature" | "humidity" | "co2" | "pm25" | "noise"
    unit: str               # "°C" | "%" | "ppm" | "μg/m³" | "dB"
    normal_min: float
    normal_max: float
    warning_threshold: float
    critical_threshold: float
    description: str


@dataclass
class RoomTwin:
    """
    실내 공간의 디지털 트윈 (가상 쌍둥이).
    물리적 센서 없이 공간 메타데이터 + 가상 센서 값을 통합 관리.
    """
    room_id: str
    name: str               # "회의실 A", "사무공간 1구역" 등
    floor: int
    area_m2: float
    zone: str               # 공간 용도: "office" | "meeting" | "lobby" | "lab"
    capacity: int           # 최대 수용 인원
    sensors: Dict[str, SensorSpec] = field(default_factory=dict)
    state: Dict = field(default_factory=dict)           # 현재 센서 상태 스냅샷
    state_history: List[Dict] = field(default_factory=list)  # 시계열 이력
    anomaly_log: List[Dict] = field(default_factory=list)    # 이상 감지 이력
    position: Dict = field(default_factory=dict)        # Three.js 3D 좌표

    def attach_sensor(self, spec: SensorSpec):
        self.sensors[spec.sensor_type] = spec

    def update_state(self, readings: Dict[str, float]):
        """센서 값 수신 시 트윈 상태 동기화 (Level 2: Live State Sync)"""
        ts = time.time()
        snapshot = {
            "timestamp": ts,
            "room_id": self.room_id,
            "readings": readings,
            "occupancy_estimate": self._estimate_occupancy(readings),
            "overall_status": self._evaluate_status(readings),
        }
        self.state = snapshot
        self.state_history.append(snapshot)
        # 메모리 절약: 최근 3600개만 유지 (1초 간격 기준 1시간)
        if len(self.state_history) > 3600:
            self.state_history = self.state_history[-3600:]
        return snapshot

    def get_trend(self, sensor_type: str, window: int = 30) -> str:
        """최근 N개 샘플의 트렌드 분석 (상승/하강/안정)"""
        if len(self.state_history) < window:
            return "데이터 부족"
        recent = [
            s["readings"].get(sensor_type, 0)
            for s in self.state_history[-window:]
        ]
        delta = recent[-1] - recent[0]
        if abs(delta) < 1:
            return "안정"
        return f"{'상승' if delta > 0 else '하강'} ({delta:+.1f})"

    def get_context_for_ai(self) -> str:
        """
        Level 3: AI 추론용 컨텍스트 생성.
        단순 센서값이 아닌 공간 메타데이터 + 트렌드 + 이력을 포함.
        이것이 '디지털 트윈'과 '단순 센서 대시보드'의 핵심 차이입니다.
        """
        readings = self.state.get("readings", {})
        lines = [
            f"[공간 정보] {self.name} ({self.floor}층, {self.area_m2}㎡, 용도: {self.zone}, 정원: {self.capacity}명)",
            f"[추정 점유] {self.state.get('occupancy_estimate', '?')}명",
            f"[현재 상태] 종합: {self.state.get('overall_status', '?')}",
            "",
            "[센서 현황]",
        ]
        for stype, spec in self.sensors.items():
            val = readings.get(stype, "N/A")
            trend = self.get_trend(stype)
            status = "정상"
            if isinstance(val, float):
                if val >= spec.critical_threshold:
                    status = "위험"
                elif val >= spec.warning_threshold:
                    status = "경고"
            lines.append(
                f"  - {spec.description}: {val}{spec.unit} "
                f"[{status}] 트렌드: {trend} "
                f"(정상 {spec.normal_min}~{spec.normal_max}{spec.unit})"
            )
        if self.anomaly_log:
            last = self.anomaly_log[-1]
            lines += ["", f"[최근 이상 이력] {last.get('message', '')} ({last.get('time', '')})"]
        return "\n".join(lines)

    def _estimate_occupancy(self, readings: Dict) -> int:
        """CO2 농도로 점유 인원 추정 (400ppm 기준, 1인당 약 25ppm 증가)"""
        co2 = readings.get("co2", 400)
        estimated = max(0, int((co2 - 400) / 25))
        return min(estimated, self.capacity)

    def _evaluate_status(self, readings: Dict) -> str:
        for stype, spec in self.sensors.items():
            val = readings.get(stype, spec.normal_min)
            if val >= spec.critical_threshold:
                return "위험"
        for stype, spec in self.sensors.items():
            val = readings.get(stype, spec.normal_min)
            if val >= spec.warning_threshold:
                return "경고"
        return "정상"


@dataclass
class BuildingTwin:
    """건물 전체의 디지털 트윈 - 여러 RoomTwin을 통합 관리"""
    building_id: str
    name: str
    total_floors: int
    rooms: Dict[str, RoomTwin] = field(default_factory=dict)

    def add_room(self, room: RoomTwin):
        self.rooms[room.room_id] = room

    def get_building_summary(self) -> Dict:
        total = len(self.rooms)
        status_counts = {"정상": 0, "경고": 0, "위험": 0}
        for room in self.rooms.values():
            s = room.state.get("overall_status", "정상")
            status_counts[s] = status_counts.get(s, 0) + 1
        return {
            "building": self.name,
            "total_rooms": total,
            "status": status_counts,
            "alert_rooms": [
                r.name for r in self.rooms.values()
                if r.state.get("overall_status") in ("경고", "위험")
            ],
        }
