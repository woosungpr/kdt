"""
XGBoost + RandomForest + LogisticRegression 앙상블 흡연 감지 모델.
가상 훈련 데이터로 학습 후 실시간 추론에 사용됩니다.

앙상블 전략: Soft Voting (각 모델의 확률값 평균)
  - XGBoost:           정밀도 높음, 비선형 패턴 포착
  - RandomForest:      과적합 방지, 노이즈에 강함
  - LogisticRegression: 빠른 추론, 선형 기준선
"""
import numpy as np
import os
import pickle
from typing import Dict, Tuple

from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import xgboost as xgb

from app.services.smoking_generator import generate_training_dataset

MODEL_PATH = os.path.join(os.path.dirname(__file__), "../../../data/smoking_model.pkl")
FEATURE_NAMES = ["co2", "pm25", "voc", "temperature", "humidity",
                 "co2_delta", "pm25_delta", "voc_delta"]


class SmokingDetector:
    """
    앙상블 기반 흡연 감지기.
    XGBoost + RandomForest + LogisticRegression의 소프트 보팅.
    """

    def __init__(self):
        self.scaler = StandardScaler()
        self.model = None
        self._prev_readings: Dict[str, Dict] = {}   # 변화율 계산용
        self._load_or_train()

    def _load_or_train(self):
        """저장된 모델 로드, 없으면 학습"""
        os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
        if os.path.exists(MODEL_PATH):
            with open(MODEL_PATH, "rb") as f:
                saved = pickle.load(f)
                self.model  = saved["model"]
                self.scaler = saved["scaler"]
            print("[SmokingDetector] 저장된 모델 로드 완료")
        else:
            print("[SmokingDetector] 모델 학습 시작...")
            self._train()

    def _train(self):
        """가상 데이터로 앙상블 모델 학습"""
        X, y = generate_training_dataset(n_normal=600, n_smoking=400)
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )

        X_train_s = self.scaler.fit_transform(X_train)
        X_test_s  = self.scaler.transform(X_test)

        # 개별 모델 정의
        xgb_model = xgb.XGBClassifier(
            n_estimators=100,
            max_depth=4,
            learning_rate=0.1,
            use_label_encoder=False,
            eval_metric="logloss",
            random_state=42,
            verbosity=0,
        )
        rf_model = RandomForestClassifier(
            n_estimators=100,
            max_depth=6,
            random_state=42,
            n_jobs=-1,
        )
        lr_model = LogisticRegression(
            C=1.0,
            max_iter=500,
            random_state=42,
        )

        # 소프트 보팅 앙상블
        self.model = VotingClassifier(
            estimators=[
                ("xgb", xgb_model),
                ("rf",  rf_model),
                ("lr",  lr_model),
            ],
            voting="soft",          # 확률값 평균
            weights=[3, 2, 1],      # XGBoost 가중치 높게
        )

        self.model.fit(X_train_s, y_train)

        # 성능 평가
        y_pred = self.model.predict(X_test_s)
        report = classification_report(y_test, y_pred,
                                       target_names=["정상", "흡연"],
                                       output_dict=True)
        acc = report["accuracy"]
        prec = report["흡연"]["precision"]
        rec  = report["흡연"]["recall"]
        print(f"[SmokingDetector] 학습 완료 — 정확도: {acc:.3f}, "
              f"흡연 정밀도: {prec:.3f}, 재현율: {rec:.3f}")

        # 모델 저장
        with open(MODEL_PATH, "wb") as f:
            pickle.dump({"model": self.model, "scaler": self.scaler}, f)
        print(f"[SmokingDetector] 모델 저장: {MODEL_PATH}")

    def predict(self, room_id: str, readings: Dict[str, float]) -> Dict:
        """
        실시간 센서값으로 흡연 확률 추론.
        반환: {
            "smoking_prob": 0.0~1.0,
            "is_smoking": bool,
            "confidence": "높음"|"보통"|"낮음",
            "key_signals": ["VOC 급등", ...],
        }
        """
        # 변화율 계산
        prev = self._prev_readings.get(room_id, readings)
        co2_d  = readings.get("co2",  0) - prev.get("co2",  0)
        pm25_d = readings.get("pm25", 0) - prev.get("pm25", 0)
        voc_d  = readings.get("voc",  0) - prev.get("voc",  0)
        self._prev_readings[room_id] = dict(readings)

        features = np.array([[
            readings.get("co2",  400),
            readings.get("pm25", 10),
            readings.get("voc",  100),
            readings.get("temperature", 22),
            readings.get("humidity", 50),
            co2_d, pm25_d, voc_d,
        ]])

        features_s = self.scaler.transform(features)
        prob = float(self.model.predict_proba(features_s)[0][1])
        is_smoking = prob >= 0.65

        # 주요 신호 분석
        signals = []
        if readings.get("voc", 0) > 400:
            signals.append("VOC 급등")
        if readings.get("pm25", 0) > 60:
            signals.append("PM2.5 급등")
        if voc_d > 50:
            signals.append("VOC 변화율 이상")
        if pm25_d > 20:
            signals.append("PM2.5 변화율 이상")

        confidence = "높음" if abs(prob - 0.5) > 0.3 else \
                     "보통" if abs(prob - 0.5) > 0.15 else "낮음"

        return {
            "room_id":      room_id,
            "smoking_prob": round(prob, 3),
            "is_smoking":   is_smoking,
            "confidence":   confidence,
            "key_signals":  signals,
            "model_votes": self._get_individual_votes(features_s),
        }

    def _get_individual_votes(self, features_s: np.ndarray) -> Dict:
        """개별 모델 예측 확률 (설명가능성)"""
        votes = {}
        for name, estimator in self.model.named_estimators_.items():
            try:
                p = float(estimator.predict_proba(features_s)[0][1])
                votes[name] = round(p, 3)
            except Exception:
                votes[name] = 0.0
        return votes
