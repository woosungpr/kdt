"""
화재 감지 시스템 (최적화 버전 - 연기 확산 효과 완벽 구현).
1. FireVideoGenerator: OpenCV로 가상 화재 영상 프레임 생성
2. YOLOFireDetector:   YOLO 스타일 탐지 시뮬레이터
   (실제 ultralytics YOLO 설치 시 실제 모델로 교체 가능)
"""
import cv2
import numpy as np
import base64
import time
import math
import os
from typing import Dict, List, Optional, Tuple
from PIL import Image, ImageDraw, ImageFont

# ── 한글 폰트 설정 ────────────────────────────────────
FONT_PATH = None
KOREAN_FONT = None

def _init_korean_font():
    """OS별 한글 폰트 초기화"""
    global FONT_PATH, KOREAN_FONT
    
    font_paths = []
    if os.name == 'nt':  # Windows
        font_paths = [
            "C:\\Windows\\Fonts\\malgun.ttf",
            "C:\\Windows\\Fonts\\arial.ttf",
        ]
    elif os.uname().sysname == 'Darwin':  # Mac
        font_paths = [
            "/Library/Fonts/AppleGothic.ttf",
            "/System/Library/Fonts/AppleSDGothicNeo.ttc",
        ]
    else:  # Linux
        font_paths = [
            "/usr/share/fonts/noto-cjk/NotoSansCJK-Regular.ttc",
            "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.otf",
            "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        ]
    
    for path in font_paths:
        if os.path.exists(path):
            try:
                FONT_PATH = path
                KOREAN_FONT = ImageFont.truetype(path, 16)
                print(f"[한글폰트] {path} 로드 완료")
                return True
            except Exception as e:
                print(f"[한글폰트] {path} 로드 실패: {e}")
    
    print("[한글폰트] 사용 가능한 폰트 없음 - ASCII 텍스트만 사용됨")
    return False

# 초기화
_init_korean_font()


def _draw_korean_text(frame: np.ndarray, text: str, x: int, y: int, 
                     color: Tuple[int, int, int] = (180, 180, 180)) -> np.ndarray:
    """한글 텍스트를 프레임에 그리기"""
    if KOREAN_FONT is None:
        cv2.putText(frame, text.encode('utf-8', errors='ignore').decode('utf-8'), 
                   (x, y), cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
        return frame
    
    try:
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        pil_img = Image.fromarray(frame_rgb)
        draw = ImageDraw.Draw(pil_img)
        color_rgb = (color[2], color[1], color[0])
        draw.text((x, y), text, font=KOREAN_FONT, fill=color_rgb)
        frame_rgb = np.array(pil_img)
        frame = cv2.cvtColor(frame_rgb, cv2.COLOR_RGB2BGR)
        return frame
    except Exception as e:
        print(f"[경고] 한글 텍스트 렌더링 실패: {e}")
        return frame


class FireVideoGenerator:
    """OpenCV 기반 가상 화재 영상 프레임 생성기 (최적화 연기 확산)"""

    def __init__(self, width: int = 640, height: int = 480):
        self.W = width
        self.H = height
        self._frame_idx = 0
        self._fire_active = False
        self._fire_start  = 0.0
        self._fire_x      = width  // 2
        self._fire_y      = height - 60
        self._fire_size   = 0.0
        self._smoke_particles: List[Dict] = []
        self._smoke_map = np.zeros((height, width), dtype=np.float32)
        
        self._smoking_active = False
        
        self.room_name = "3F SERVER ROOM"
        self.cam_id = "CAM-01"

    def set_room_info(self, room_name: str, cam_id: str):
        """카메라 정보 설정"""
        self.room_name = room_name
        self.cam_id = cam_id

    def trigger_fire(self, x_ratio: float = 0.5, y_ratio: float = 0.8):
        """화재 발생 트리거"""
        self._fire_active = True
        self._fire_start  = time.time()
        self._fire_x = int(self.W * x_ratio)
        self._fire_y = int(self.H * y_ratio)
        self._fire_size = 0.0
        self._smoke_particles = []
        self._smoke_map = np.zeros((self.H, self.W), dtype=np.float32)
        print(f"[FireGen] 화재 발생: ({self._fire_x}, {self._fire_y})")

    def stop_fire(self):
        self._fire_active = False
        self._fire_size   = 0.0
        self._smoke_particles = []
        self._smoke_map = np.zeros((self.H, self.W), dtype=np.float32)

    def get_frame_base64(self) -> Tuple[str, bool]:
        """프레임을 base64 JPEG로 반환"""
        frame = self._render_frame()
        _, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
        b64 = base64.b64encode(buf.tobytes()).decode("utf-8")
        self._frame_idx += 1
        return b64, self._fire_active

    def _render_frame(self) -> np.ndarray:
        """실내 배경 + 화재 효과 합성"""
        frame = np.zeros((self.H, self.W, 3), dtype=np.uint8)
        cv2.rectangle(frame, (0, self.H - 80), (self.W, self.H), (40, 35, 30), -1)
        cv2.rectangle(frame, (0, 0), (self.W, self.H - 80), (55, 50, 48), -1)
        cv2.rectangle(frame, (80, 60), (200, 200), (100, 120, 140), -1)
        cv2.rectangle(frame, (80, 60), (200, 200), (150, 160, 170), 2)
        cv2.rectangle(frame, (self.W - 120, self.H - 260), (self.W - 20, self.H - 80), (70, 55, 45), -1)
        
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        frame = _draw_korean_text(frame, f"{self.cam_id}  {ts}", 10, 20, (180, 180, 180))
        frame = _draw_korean_text(frame, self.room_name, 10, self.H - 10, (160, 160, 160))

        # 2. 🔥 화재 시뮬레이션
        if self._fire_active:
            elapsed = time.time() - self._fire_start
            self._fire_size = min(1.0, elapsed / 8.0)
            # 화재 시에는 기존 smoke_map을 화재용으로 사용
            frame = self._draw_fire(frame, elapsed)
            frame = self._draw_smoke(frame, elapsed)
            frame = self._draw_detection_box(frame)  

        # 3. 🚬 담배 연기 시뮬레이션 (화재가 아닐 때도 독립적으로 작동)
        # 핵심 수정: smoking_active일 때 smoke_map이 유지되도록 함
        if self._smoking_active:
            frame = self._draw_cigarette_smoke(frame)
    
        return frame

    def _draw_fire(self, frame: np.ndarray, elapsed: float) -> np.ndarray:
        """화염 효과"""
        cx, cy = self._fire_x, self._fire_y
        base_r = int(30 * self._fire_size)
        overlay = frame.copy()

        layers = [
            (base_r * 2,    base_r * 3,    (0,  30, 200)),
            (base_r,        base_r * 2,    (0, 100, 255)),
            (base_r // 2,   base_r,        (0, 180, 255)),
            (base_r // 4,   base_r // 2,   (50, 220, 255)),
        ]
        flicker = 0.85 + 0.15 * math.sin(elapsed * 12)

        for rx, ry, color in layers:
            rx = max(2, int(rx * flicker))
            ry = max(3, int(ry * flicker))
            cv2.ellipse(overlay, (cx, cy), (rx, ry), 0, 180, 360, color, -1)

        cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)
        return frame

   
    def _draw_smoke(self, frame: np.ndarray, elapsed: float) -> np.ndarray:
        """연기 파티클 시뮬레이션"""
        # 파티클 생성
        if self._fire_size > 0.1 and self._frame_idx % 2 == 0:
            for _ in range(2):
                self._smoke_particles.append({
                    "x": self._fire_x + np.random.randint(-25, 25),
                    "y": self._fire_y - 5,
                    "vx": np.random.uniform(-1.2, 1.2),
                    "vy": np.random.uniform(-3.0, -1.5),
                    "r":  np.random.randint(10, 28),
                    "age": 0,
                })

        overlay = frame.copy()
        alive = []
        for p in self._smoke_particles:
            p["x"]   += p["vx"]
            p["y"]   += p["vy"]
            p["r"]   += 0.5
            p["age"] += 1
            
            max_age = 60
            alpha = max(0, 1.0 - (p["age"] / max_age))
            
            if alpha > 0.01 and 0 < p["x"] < self.W and p["y"] > 0:
                gray = int(120 - p["age"] * 0.5)
                color = (gray, gray, gray)
                
                cv2.circle(overlay, (int(p["x"]), int(p["y"])), max(1, int(p["r"])),
                           color, -1)
                alive.append(p)
        
        self._smoke_particles = alive[-120:]

        cv2.addWeighted(overlay, 0.65, frame, 0.35, 0, frame)
        return frame
    
    def _draw_cigarette_smoke(self, frame: np.ndarray) -> np.ndarray:
        """🚬 담배 연기 (완전 하얀색 + 반원형 확산 시뮬레이션)"""
        
        # 1️⃣ 연기 맵 초기화 (매 프레임 새로 그립니다 - 확산 효과를 위해)
        self._smoke_map = np.zeros((self.H, self.W), dtype=np.float32)

        # 2️⃣ 반원형 확산 로직 (시간/프레임 기반)
        # 프레임 인덱스를 이용해 반지름을 서서히 키웁니다.
        # % 120: 120프레임(약 4초)마다 확산이 초기화되어 반복됩니다.
        diffusion_cycle = self._frame_idx % 120 
        
        # 반지름 계산: 시간이 지날수록 커짐 (최대 150 픽셀)
        max_radius = 150
        current_radius = (diffusion_cycle / 120) * max_radius
        
        # 확산 중심점 (바닥 중앙)
        cx, cy = int(self.W * 0.5), int(self.H * 0.8)

        # 3️⃣ 수학적 반원 그리기 (속도 최적화를 위해 numpy 연산 사용)
        # 화면의 모든 픽셀 좌표 생성
        y, x = np.ogrid[:self.H, :self.W]
        
        # 중심점으로부터의 거리 계산 (원 방정식: (x-cx)^2 + (y-cy)^2 = r^2)
        dist_sq = (x - cx)**2 + (y - cy)**2
        
        # 현재 반지름 이내에 있는 픽셀들만 선택 (원 내부)
        # AND cy 보다 위쪽에 있는 픽셀들만 선택 (반원)
        mask = (dist_sq <= current_radius**2) & (y <= cy)
        
        # 4️⃣ 농도 및 부드러운 가장자리 처리
        if np.any(mask):
            # 거리에 따른 농도 계산 (중심은 진하고, 가장자리는 연하게)
            dist = np.sqrt(dist_sq[mask])
            # 0.0(가장자리) ~ 1.0(중심) 사이 값으로 정규화
            opacity = 1.0 - (dist / current_radius)
            
            # 확산 초반에는 더 진하게, 후반에는 연하게 (사라지는 효과)
            time_fade = 1.0 - (diffusion_cycle / 120)
            
            # 최종 농도 적용 (확산 모양 + 시간 경과에 따른 사라짐)
            self._smoke_map[mask] = opacity * time_fade * 0.8 # 0.8은 최대 투명도

        # 5️⃣ 자연스러운 확산 (Gaussian Blur - 너비 확장 유지)
        smoke_blur = cv2.GaussianBlur(self._smoke_map, (51, 51), 0)

        # 6️⃣ ⭐ 핵심: 하얀색 렌더링 및 진함 유지
        # 연기 자체의 밝기를 최대화 (255)
        smoke_vis = (smoke_blur * 255).astype(np.uint8)
        
        # ⭐ 완전 하얀색 (255, 255, 255)으로 설정
        smoke_3ch = cv2.merge([smoke_vis, smoke_vis, smoke_vis])

        # 7️⃣ 배경과 합성 (가중치 상향 유지)
        result = cv2.addWeighted(frame, 1.0, smoke_3ch, 0.7, 0)

        return result
    
    def _draw_detection_box(self, frame: np.ndarray) -> np.ndarray:
        """YOLO 스타일 탐지 박스"""
        s = self._fire_size
        bw = int(120 * s)
        bh = int(150 * s)
        x1 = max(0, self._fire_x - bw // 2)
        y1 = max(0, self._fire_y - bh)
        x2 = min(self.W, x1 + bw)
        y2 = min(self.H, self._fire_y + 20)

        conf = min(0.99, 0.5 + s * 0.45)
        color = (0, 60, 255)

        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
        label = f"FIRE {conf:.2f}"
        (lw, lh), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 1)
        cv2.rectangle(frame, (x1, y1 - lh - 6), (x1 + lw + 6, y1), color, -1)
        cv2.putText(frame, label, (x1 + 3, y1 - 4),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1)

        if int(time.time() * 2) % 2 == 0:
            frame = _draw_korean_text(frame, "!! 화재 감지 !!", 
                                     self.W // 2 - 100, 50, (0, 0, 255))

        return frame


class YOLOFireDetector:
    """YOLO 스타일 화재 탐지기"""

    def __init__(self):
        self._use_real_yolo = False
        self._real_model    = None
        self._try_load_yolo()

    def _try_load_yolo(self):
        """실제 YOLO 모델 로드 시도"""
        try:
            from ultralytics import YOLO
            model_path = "yolov8n.pt"
            self._real_model   = YOLO(model_path)
            self._use_real_yolo = True
            print("[YOLO] 실제 YOLOv8 모델 로드 완료")
        except ImportError:
            print("[YOLO] ultralytics 미설치 → 시뮬레이션 모드")
        except Exception as e:
            print(f"[YOLO] 모델 로드 실패 ({e}) → 시뮬레이션 모드")

    def detect(self, frame_b64: str, fire_active: bool) -> Dict:
        """프레임에서 화재 탐지"""
        if self._use_real_yolo and self._real_model:
            return self._detect_real(frame_b64)
        else:
            return self._detect_sim(fire_active)

    def _detect_sim(self, fire_active: bool) -> Dict:
        """시뮬레이션 모드"""
        if fire_active:
            conf = np.random.uniform(0.72, 0.97)
            return {
                "fire_detected":  True,
                "smoke_detected": np.random.random() > 0.3,
                "confidence":     round(conf, 3),
                "bboxes": [{"label": "fire", "conf": round(conf, 2),
                             "x1": 260, "y1": 200, "x2": 380, "y2": 420}],
                "mode": "yolo_sim",
            }
        else:
            false_positive = np.random.random() < 0.02
            return {
                "fire_detected":  false_positive,
                "smoke_detected": False,
                "confidence":     round(np.random.uniform(0.05, 0.18), 3) if not false_positive else 0.0,
                "bboxes":         [],
                "mode":           "yolo_sim",
            }

    def _detect_real(self, frame_b64: str) -> Dict:
        """실제 YOLO 추론"""
        try:
            img_bytes = base64.b64decode(frame_b64)
            nparr = np.frombuffer(img_bytes, np.uint8)
            img   = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            results = self._real_model(img, verbose=False)
            bboxes, fire_det = [], False
            for r in results:
                for box in r.boxes:
                    conf  = float(box.conf[0])
                    cls   = int(box.cls[0])
                    label = self._real_model.names[cls]
                    if conf > 0.4:
                        x1,y1,x2,y2 = map(int, box.xyxy[0])
                        bboxes.append({"label": label, "conf": round(conf,2),
                                        "x1": x1, "y1": y1, "x2": x2, "y2": y2})
                        if "fire" in label.lower() or "smoke" in label.lower():
                            fire_det = True
            return {"fire_detected": fire_det, "smoke_detected": False,
                    "confidence": max((b["conf"] for b in bboxes), default=0.0),
                    "bboxes": bboxes, "mode": "yolo_real"}
        except Exception as e:
            return {"fire_detected": False, "smoke_detected": False,
                    "confidence": 0.0, "bboxes": [], "mode": "yolo_error"}


class MultiRoomCameraManager:
    """5개 공간의 카메라 통합 관리"""

    def __init__(self, room_ids: List[str]):
        self.room_ids = room_ids
        self.rooms = {}
        
        room_names = {
            "r-101": "로비",
            "r-201": "사무공간 A",
            "r-202": "회의실 1",
            "r-301": "사무공간 B",
            "r-302": "서버실",
        }
        
        for rid in room_ids:
            self.rooms[rid] = {
                "name": room_names.get(rid, rid),
                "gen": FireVideoGenerator(),
                "fire_active": False,
                "smoking_active": False,
            }
            self.rooms[rid]["gen"].set_room_info(room_names.get(rid, rid), f"CAM-{rid[-3:]}")

    def trigger_fire(self, room_id: str, x_ratio: float = 0.5, y_ratio: float = 0.8):
        """화재 발생"""
        if room_id in self.rooms:
            self.rooms[room_id]["fire_active"] = True
            self.rooms[room_id]["gen"].trigger_fire(x_ratio, y_ratio)

    def stop_fire(self, room_id: str):
        """화재 진압"""
        if room_id in self.rooms:
            self.rooms[room_id]["fire_active"] = False
            self.rooms[room_id]["gen"].stop_fire()

    def trigger_smoking(self, room_id: str):
        self._smoking_active = True
        """흡연 감지"""
        if room_id in self.rooms:
            self.rooms[room_id]["smoking_active"] = True
            self.rooms[room_id]["gen"]._smoking_active = True   # ✅ 추가            

    def stop_smoking(self, room_id: str):
        self._smoking_active = False
        """흡연 감지 종료"""
        if room_id in self.rooms:
            self.rooms[room_id]["smoking_active"] = False
            self.rooms[room_id]["gen"]._smoking_active = False  # ✅ 추가
            
    def get_all_frames(self) -> Dict[str, Dict]:
        """모든 공간의 프레임 반환"""
        frames = {}
        for rid in self.room_ids:
            if rid in self.rooms:
                frame_b64, _ = self.rooms[rid]["gen"].get_frame_base64()
                frames[rid] = {"frame": frame_b64}
        return frames

    def get_alert_rooms(self) -> List[Dict]:
        """경보 발생 중인 공간 목록"""
        alerts = []
        for rid in self.room_ids:
            if rid in self.rooms:
                room = self.rooms[rid]
                if room["fire_active"]:
                    alerts.append({
                        "room_id": rid,
                        "room_label": room["name"],
                        "alert_type": "fire",
                    })
                elif room["smoking_active"]:
                    alerts.append({
                        "room_id": rid,
                        "room_label": room["name"],
                        "alert_type": "smoke",
                    })
        return alerts
