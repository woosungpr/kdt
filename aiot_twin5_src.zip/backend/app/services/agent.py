"""
AIoT Agent 서비스 - OpenAI API 버전
이상 감지(규칙 기반) → OpenAI GPT 원인 분석 → 대응 조치 자동 생성
"""
import os
import time
import json
from datetime import datetime
from typing import Dict, List, Optional
from openai import OpenAI
from app.models.twin import RoomTwin, BuildingTwin

GPT_MODEL = "gpt-4o-mini"   # 비용 절약. gpt-4o 로 바꾸면 더 정확

SYSTEM_PROMPT = """당신은 스마트 빌딩의 AIoT 관제 에이전트입니다.
실내 환경 센서 데이터를 분석하여 이상 원인을 진단하고 구체적인 대응 조치를 제시합니다.

반드시 아래 JSON 형식으로만 응답하세요. 다른 텍스트는 절대 포함하지 마세요:
{
  "severity": "정상" 또는 "경고" 또는 "위험",
  "cause": "이상 원인 1~2문장",
  "actions": ["즉시 조치 1", "즉시 조치 2", "예방 조치 1"],
  "predicted_risk": "조치 안 할 경우 30분 내 예상 상황",
  "confidence": 0에서 100 사이 숫자
}"""


class AnomalyDetector:
    """규칙 기반 1차 이상 감지"""

    def detect(self, room: RoomTwin) -> Optional[Dict]:
        readings = room.state.get("readings", {})
        anomalies = []
        for stype, spec in room.sensors.items():
            val = readings.get(stype)
            if val is None:
                continue
            if val >= spec.critical_threshold:
                anomalies.append({
                    "sensor": stype, "value": val,
                    "threshold": spec.critical_threshold,
                    "level": "위험", "desc": spec.description, "unit": spec.unit,
                })
            elif val >= spec.warning_threshold:
                anomalies.append({
                    "sensor": stype, "value": val,
                    "threshold": spec.warning_threshold,
                    "level": "경고", "desc": spec.description, "unit": spec.unit,
                })
        if not anomalies:
            return None
        worst = max(anomalies, key=lambda a: 1 if a["level"] == "위험" else 0)
        return {
            "room_id": room.room_id,
            "room_name": room.name,
            "anomalies": anomalies,
            "worst_level": worst["level"],
            "detected_at": datetime.now().strftime("%H:%M:%S"),
        }


class AIoTAgent:
    def __init__(self):
        self.detector = AnomalyDetector()
        self._client = None
        self.action_log: List[Dict] = []

    @property
    def client(self) -> OpenAI:
        """OpenAI 클라이언트 지연 초기화 - 서버 시작 오류 방지"""
        if self._client is None:
            api_key = os.getenv("OPENAI_API_KEY")
            if not api_key:
                raise ValueError(
                    ".env 파일에 OPENAI_API_KEY가 설정되지 않았습니다.\n"
                    "backend/.env 파일을 열고 OPENAI_API_KEY=sk-proj-... 를 추가하세요."
                )
            self._client = OpenAI(api_key=api_key)
        return self._client

    def analyze_room(self, room: RoomTwin) -> Optional[Dict]:
        """단일 공간 분석: 이상 감지 → 디지털 트윈 컨텍스트 → GPT 분석 → 조치 생성"""
        anomaly = self.detector.detect(room)
        if not anomaly:
            return None

        context = room.get_context_for_ai()
        user_message = (
            f"다음 실내 공간에서 이상이 감지되었습니다. 분석해주세요.\n\n"
            f"{context}\n\n"
            f"감지된 이상:\n{json.dumps(anomaly['anomalies'], ensure_ascii=False, indent=2)}"
        )

        try:
            response = self.client.chat.completions.create(
                model=GPT_MODEL,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user",   "content": user_message},
                ],
                temperature=0.3,
                max_tokens=500,
                response_format={"type": "json_object"},  # JSON 모드 강제
            )
            analysis = json.loads(response.choices[0].message.content)
        except Exception as e:
            analysis = {
                "severity": anomaly["worst_level"],
                "cause": f"AI 분석 오류({e}) - 규칙 기반 감지: {anomaly['anomalies'][0]['desc']} 초과",
                "actions": ["담당자에게 즉시 보고", "현장 육안 확인", "공조 시스템 점검"],
                "predicted_risk": "지속 시 재실자 건강 영향 가능",
                "confidence": 60,
            }

        result = {
            "room_id": room.room_id,
            "room_name": room.name,
            "floor": room.floor,
            "timestamp": datetime.now().isoformat(),
            "anomaly": anomaly,
            "ai_analysis": analysis,
            "work_order": self._generate_work_order(room, analysis),
        }
        room.anomaly_log.append({
            "time": anomaly["detected_at"],
            "message": analysis.get("cause", ""),
            "severity": analysis.get("severity", "경고"),
        })
        self.action_log.append(result)
        return result

    def analyze_building(self, building: BuildingTwin) -> List[Dict]:
        results = []
        for room in building.rooms.values():
            r = self.analyze_room(room)
            if r:
                results.append(r)
        return results

    def chat(self, question: str, building: BuildingTwin) -> str:
        """자연어 관제 채팅"""
        summary = building.get_building_summary()
        room_contexts = "\n\n".join(r.get_context_for_ai() for r in building.rooms.values())
        prompt = (
            f"건물 현황:\n{json.dumps(summary, ensure_ascii=False)}\n\n"
            f"전체 공간 상태:\n{room_contexts}\n\n"
            f"관제 담당자 질문: {question}\n\n"
            f"위 정보를 바탕으로 간결하고 정확하게 답변하세요."
        )
        try:
            response = self.client.chat.completions.create(
                model=GPT_MODEL,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.4,
                max_tokens=400,
            )
            return response.choices[0].message.content.strip()
        except Exception as e:
            return f"AI 응답 오류: {e}"

    @staticmethod
    def _generate_work_order(room: RoomTwin, analysis: Dict) -> Dict:
        return {
            "work_order_id": f"WO-{int(time.time())}",
            "issued_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "location": f"{room.floor}층 {room.name}",
            "priority": "긴급" if analysis.get("severity") == "위험" else "일반",
            "title": f"[{analysis.get('severity','경고')}] {room.name} 환경 이상",
            "description": analysis.get("cause", ""),
            "actions": analysis.get("actions", []),
            "assigned_to": "시설 관리팀",
            "due_time": "30분 이내",
        }
        