"""
가상 센서 데이터 제너레이터.
실제 IoT 센서 없이 시간대·공간 특성을 반영한 현실감 있는 데이터를 생성합니다.
시연 시 'inject_scenario()' 메서드로 이상 패턴을 강제 주입할 수 있습니다.
"""
import numpy as np
import time
from datetime import datetime
from typing import Dict, Optional
from app.models.twin import RoomTwin, SensorSpec


class TelemetryGenerator:
    """공간 유형별 시계열 센서 데이터 생성기"""

    # 공간 유형별 기본 온도 오프셋
    ZONE_TEMP_OFFSET = {
        "office":  0.0,
        "meeting": 1.5,   # 회의실은 체온으로 약간 높음
        "lobby":  -0.5,
        "lab":    -3.0,   # 서버실은 냉방 강함
    }

    def __init__(self, room: RoomTwin):
        self.room = room
        self._scenario: Optional[str] = None
        self._scenario_ticks: int = 0
        self._noise_seed = hash(room.room_id) % 1000  # 방마다 다른 노이즈 패턴
        np.random.seed(self._noise_seed)
        self._scenario_total_ticks: int = 0  # 추가

    def inject_scenario(self, scenario: str, duration_ticks: int = 18000):
        """
        시연용 이상 시나리오 강제 주입.
        scenario: "co2_spike" | "overheating" | "humidity_crisis" | "pm25_spike" | "multi_alarm" | "normal"
        """
        self._scenario = scenario if scenario != "normal" else None
        self._scenario_ticks = duration_ticks
        self._scenario_total_ticks = duration_ticks  # ← 전체 틱 저장 추가
        print(f"[Generator] {self.room.name}: 시나리오 '{scenario}' 주입 ({duration_ticks}틱)")
        
    def generate(self) -> Dict[str, float]:
        """현재 시각·공간 특성을 반영한 센서값 1세트 생성"""
        hour = datetime.now().hour
        readings = {}

        for stype, spec in self.room.sensors.items():
            val = self._base_value(stype, spec, hour)
            val = self._apply_scenario(val, stype, spec)
            val += np.random.normal(0, (spec.normal_max - spec.normal_min) * 0.01)
            readings[stype] = round(float(np.clip(val, 0, spec.critical_threshold * 1.2)), 2)

        if self._scenario_ticks > 0:
            self._scenario_ticks -= 1
            if self._scenario_ticks == 0:
                self._scenario = None

        return readings

    def _base_value(self, stype: str, spec: SensorSpec, hour: int) -> float:
        """시간대를 반영한 기본 센서값 (업무시간 피크 패턴)"""
        work_factor = self._work_hour_factor(hour)
        zone = self.room.zone

        if stype == "temperature":
            base = 20 + self.ZONE_TEMP_OFFSET.get(zone, 0)
            return base + work_factor * 3.0  # 재실 시 최대 +3°C

        elif stype == "humidity":
            base = 50
            return base + work_factor * 5.0  # 재실 시 습도 상승

        elif stype == "co2":
            base = 420  # 외기 CO2
                # 로비는 환기가 잘되므로 CO2 증가 최소화
            if zone == "lobby":
                return base + work_factor * self.room.capacity * 10  # 20 → 5
            else:
                return base + work_factor * self.room.capacity * 20

        elif stype == "pm25":
            base = 10
            return base + work_factor * 8.0

        elif stype == "noise":
            base = 35
            return base + work_factor * 20.0  # 서버 가동 노이즈

        return spec.normal_min + (spec.normal_max - spec.normal_min) * 0.5

    def _apply_scenario(self, val: float, stype: str, spec: SensorSpec) -> float:
        """이상 시나리오 적용"""
        if not self._scenario:
            return val

        # progress = 1 - (self._scenario_ticks / 60)  # 0→1 점진적 상승
        # 전체 duration 대비 경과 비율로 progress 계산
        ramp_ticks = min(60, self._scenario_total_ticks * 0.1)  # 상승 구간 (최대 60틱)
        elapsed = self._scenario_total_ticks - self._scenario_ticks
        progress = min(elapsed / ramp_ticks, 1.0)  # 0→1, 이후 1.0 고정 유지
    
        if self._scenario == "co2_spike" and stype == "co2":
            # delta = max(spec.critical_threshold - val, 0)
            return val + (spec.critical_threshold - val) * progress * 0.9

        elif self._scenario == "overheating" and stype == "temperature":
            return val + (spec.critical_threshold - val) * progress * 0.85

        elif self._scenario == "humidity_crisis" and stype == "humidity":
            return val + (spec.critical_threshold - val) * progress * 0.8

        elif self._scenario == "pm25_spike" and stype == "pm25":       # ✅ 추가
            return val + (spec.critical_threshold - val) * progress * 0.9
    
        elif self._scenario == "multi_alarm":
            if stype in ("co2", "temperature"):
                return val + (spec.warning_threshold - val) * progress * 1.1

        return val

    @staticmethod
    def _work_hour_factor(hour: int) -> float:
        """시간대별 재실률 추정 (0~1). 업무시간(9-18시) 최대"""
        if 9 <= hour < 12:
            return 0.6 + (hour - 9) / 6
        elif 12 <= hour < 13:
            return 0.4  # 점심시간
        elif 13 <= hour < 18:
            return 0.7 + (18 - hour) / 20
        elif 18 <= hour < 20:
            return 0.3 - (hour - 18) / 10
        return 0.05  # 야간


class LSTMPatternEngine:
    """
    LSTM 기반 예측 시뮬레이터.
    실제 LSTM 모델 학습 없이 이동평균 + 트렌드로 예측값을 빠르게 생성합니다.
    본 프로젝트(6월)에서 TensorFlow LSTM으로 교체 가능.
    """

    def predict_next(self, history: list, steps: int = 6) -> list:
        """
        최근 이력으로 향후 N스텝 예측.
        간단한 지수 이동평균 기반 (예비 프로젝트용).
        """
        if len(history) < 5:
            return [history[-1]] * steps if history else [0] * steps

        values = [h["readings"] for h in history[-30:]]
        predictions = []

        for step in range(steps):
            pred = {}
            for stype in values[0].keys():
                series = [v.get(stype, 0) for v in values]
                # 지수 이동평균 + 트렌드 외삽
                ema = series[-1]
                alpha = 0.3
                for v in series[-10:]:
                    ema = alpha * v + (1 - alpha) * ema
                trend = (series[-1] - series[-5]) / 5 if len(series) >= 5 else 0
                pred[stype] = round(ema + trend * (step + 1), 2)
            predictions.append(pred)

        return predictions
