"""
통합 AIoT 이상 탐지 시스템 (ensemble_detector.py)
- 온도, 습도, CO2, PM2.5: XGBoost + RandomForest + LogisticRegression
- 화재: YOLO 기반 (fire_detector.py와 통합)
- 흡연: XGBoost + RandomForest + LogisticRegression (smoking_detector.py와 통합)

각 센서별 이상을 독립적으로 탐지하고 복합 위험도 계산
"""
import numpy as np
import os
import pickle
import json
from typing import Dict, List, Tuple
from datetime import datetime

from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import xgboost as xgb


# ── 경로 설정 ────────────────────────────────────
MODEL_DIR = os.path.join(os.path.dirname(__file__), "../../data")
os.makedirs(MODEL_DIR, exist_ok=True)


def _generate_temperature_dataset(n_normal=500, n_abnormal=300):
    """온도 이상 데이터 생성"""
    normal = np.random.normal(23, 2, (n_normal, 5))  # 평균 23°C, 표준편차 2
    abnormal = np.concatenate([
        np.random.uniform(0, 15, (n_abnormal // 2, 5)),   # 너무 낮음
        np.random.uniform(35, 50, (n_abnormal // 2, 5)),  # 너무 높음
    ])
    X = np.vstack([normal, abnormal])
    y = np.hstack([np.zeros(n_normal), np.ones(n_abnormal)])
    return X, y


def _generate_humidity_dataset(n_normal=500, n_abnormal=300):
    """습도 이상 데이터 생성"""
    normal = np.random.normal(50, 8, (n_normal, 5))  # 평균 50%, 표준편차 8
    abnormal = np.concatenate([
        np.random.uniform(0, 20, (n_abnormal // 2, 5)),    # 너무 낮음 (건조)
        np.random.uniform(80, 100, (n_abnormal // 2, 5)),  # 너무 높음 (습함)
    ])
    X = np.vstack([normal, abnormal])
    y = np.hstack([np.zeros(n_normal), np.ones(n_abnormal)])
    return X, y


def _generate_co2_dataset(n_normal=500, n_abnormal=300):
    """CO2 이상 데이터 생성"""
    normal = np.random.normal(600, 150, (n_normal, 5))      # 평균 600ppm
    abnormal = np.random.uniform(1200, 2500, (n_abnormal, 5))  # 이상 수치
    X = np.vstack([normal, abnormal])
    y = np.hstack([np.zeros(n_normal), np.ones(n_abnormal)])
    return X, y


def _generate_pm25_dataset(n_normal=500, n_abnormal=300):
    """PM2.5 이상 데이터 생성"""
    normal = np.random.normal(25, 10, (n_normal, 5))        # 평균 25 μg/m³
    abnormal = np.random.uniform(80, 500, (n_abnormal, 5))  # 이상 수치
    X = np.vstack([normal, abnormal])
    y = np.hstack([np.zeros(n_normal), np.ones(n_abnormal)])
    return X, y


class TemperatureDetector:
    """온도 이상 탐지 (앙상블)"""
    
    def __init__(self):
        self.scaler = StandardScaler()
        self.model = None
        self._load_or_train()
    
    def _load_or_train(self):
        model_path = os.path.join(MODEL_DIR, "temperature_model.pkl")
        os.makedirs(os.path.dirname(model_path), exist_ok=True)
        
        if os.path.exists(model_path):
            with open(model_path, "rb") as f:
                saved = pickle.load(f)
                self.model = saved["model"]
                self.scaler = saved["scaler"]
            print("[온도 탐지기] 저장된 모델 로드 완료")
        else:
            print("[온도 탐지기] 모델 학습 시작...")
            X, y = _generate_temperature_dataset()
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            
            X_train_s = self.scaler.fit_transform(X_train)
            X_test_s = self.scaler.transform(X_test)
            
            xgb_model = xgb.XGBClassifier(n_estimators=100, max_depth=4, learning_rate=0.1, 
                                         use_label_encoder=False, eval_metric="logloss", random_state=42)
            rf_model = RandomForestClassifier(n_estimators=100, max_depth=6, random_state=42, n_jobs=-1)
            lr_model = LogisticRegression(C=1.0, max_iter=500, random_state=42)
            
            self.model = VotingClassifier(
                estimators=[("xgb", xgb_model), ("rf", rf_model), ("lr", lr_model)],
                voting="soft", weights=[3, 2, 1]
            )
            
            self.model.fit(X_train_s, y_train)
            y_pred = self.model.predict(X_test_s)
            report = classification_report(y_test, y_pred, output_dict=True)
            print(f"[온도 탐지기] 정확도: {report['accuracy']:.3f}")
            
            with open(model_path, "wb") as f:
                pickle.dump({"model": self.model, "scaler": self.scaler}, f)
    
    def predict(self, temperature_value: float, history: List[float] = None, sensors_meta: Dict = None) -> Dict:
        """온도 이상 탐지"""
        if history is None:
            history = [temperature_value] * 5
        
        features = np.array([history]).reshape(1, -1)
        features_s = self.scaler.transform(features)
        prob = float(self.model.predict_proba(features_s)[0][1])
        
        is_abnormal = prob >= 0.6
        
         # ✅ sensors_meta가 있으면 그 임계값 사용, 없으면 기본값
        if sensors_meta:
            warn  = sensors_meta.get("warning_threshold",  28)
            crit  = sensors_meta.get("critical_threshold", 32)
            nmin  = sensors_meta.get("normal_min",         18)
        else:
            warn, crit, nmin = 28, 32, 15
            
        # 온도 범위 기반 추가 판단
        # if temperature_value < 15 or temperature_value > 35:
        #     is_abnormal = True
        #     prob = max(prob, 0.8)
        
        if temperature_value > warn:
            prob = max(prob, 0.65)
            is_abnormal = True
        if temperature_value > crit:
            prob = max(prob, 0.9)
            is_abnormal = True
        if temperature_value < nmin:
            prob = max(prob, 0.8)
            is_abnormal = True

        # 심각도 구분
        if temperature_value > crit:
            status = "⚠️ 위험"
        elif temperature_value > warn:
            status = "⚠️ 경고"
        else:
            status = "정상"
            
        return {
            "sensor": "temperature",
            "value":         round(float(temperature_value), 2),
            "abnormal_prob": round(float(prob), 3),
            "is_abnormal":   bool(is_abnormal),
            # "message": f"온도 {temperature_value}°C - {'⚠️ 이상' if is_abnormal else '정상'}",
             "message":       f"온도 {temperature_value}°C - {status}",
            "confidence": "높음" if abs(prob - 0.5) > 0.3 else "낮음"
        }


class HumidityDetector:
    """습도 이상 탐지"""
    
    def __init__(self):
        self.scaler = StandardScaler()
        self.model = None
        self._load_or_train()
    
    def _load_or_train(self):
        model_path = os.path.join(MODEL_DIR, "humidity_model.pkl")
        os.makedirs(os.path.dirname(model_path), exist_ok=True)
        
        if os.path.exists(model_path):
            with open(model_path, "rb") as f:
                saved = pickle.load(f)
                self.model = saved["model"]
                self.scaler = saved["scaler"]
            print("[습도 탐지기] 저장된 모델 로드 완료")
        else:
            print("[습도 탐지기] 모델 학습 시작...")
            X, y = _generate_humidity_dataset()
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            
            X_train_s = self.scaler.fit_transform(X_train)
            X_test_s = self.scaler.transform(X_test)
            
            xgb_model = xgb.XGBClassifier(n_estimators=100, max_depth=4, learning_rate=0.1,
                                         use_label_encoder=False, eval_metric="logloss", random_state=42)
            rf_model = RandomForestClassifier(n_estimators=100, max_depth=6, random_state=42, n_jobs=-1)
            lr_model = LogisticRegression(C=1.0, max_iter=500, random_state=42)
            
            self.model = VotingClassifier(
                estimators=[("xgb", xgb_model), ("rf", rf_model), ("lr", lr_model)],
                voting="soft", weights=[3, 2, 1]
            )
            
            self.model.fit(X_train_s, y_train)
            y_pred = self.model.predict(X_test_s)
            report = classification_report(y_test, y_pred, output_dict=True)
            print(f"[습도 탐지기] 정확도: {report['accuracy']:.3f}")
            
            with open(model_path, "wb") as f:
                pickle.dump({"model": self.model, "scaler": self.scaler}, f)
    
    def predict(self, humidity_value: float, history: List[float] = None, sensors_meta=None) -> Dict:
        """습도 이상 탐지"""
        if history is None:
            history = [humidity_value] * 5
        
        features = np.array([history]).reshape(1, -1)
        features_s = self.scaler.transform(features)
        prob = float(self.model.predict_proba(features_s)[0][1])
        
        is_abnormal = prob >= 0.6
        
        # if humidity_value < 20 or humidity_value > 85:
        #     is_abnormal = True
        #     prob = max(prob, 0.8)
        
        warn = sensors_meta.get("warning_threshold", 70) if sensors_meta else 70
        crit = sensors_meta.get("critical_threshold", 80) if sensors_meta else 85

        if humidity_value > warn or humidity_value < 20:
            prob = max(float(prob), 0.65)  # ✅ float() 보장
            is_abnormal = True
        if humidity_value > crit:
            prob = max(float(prob), 0.9)
            is_abnormal = True
        
        if humidity_value > crit:
            status = "⚠️ 위험"
        elif humidity_value > warn:
            status = "⚠️ 경고"
        else:
            status = "정상"
            
        return {
            "sensor":        "humidity",
            "value":         round(float(humidity_value), 2),  # ✅
            "abnormal_prob": round(float(prob), 3),            # ✅ float() 명시적 변환
            "is_abnormal":   bool(is_abnormal),                # ✅ bool() 명시적 변환
            "message":       f"습도 {humidity_value}% - {status}",
            "confidence":    "높음" if abs(prob - 0.5) > 0.3 else "낮음"
        }


class CO2Detector:
    """CO2 이상 탐지"""
    
    def __init__(self):
        self.scaler = StandardScaler()
        self.model = None
        self._load_or_train()
    
    def _load_or_train(self):
        model_path = os.path.join(MODEL_DIR, "co2_model.pkl")
        os.makedirs(os.path.dirname(model_path), exist_ok=True)
        
        if os.path.exists(model_path):
            with open(model_path, "rb") as f:
                saved = pickle.load(f)
                self.model = saved["model"]
                self.scaler = saved["scaler"]
            print("[CO2 탐지기] 저장된 모델 로드 완료")
        else:
            print("[CO2 탐지기] 모델 학습 시작...")
            X, y = _generate_co2_dataset()
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            
            X_train_s = self.scaler.fit_transform(X_train)
            X_test_s = self.scaler.transform(X_test)
            
            xgb_model = xgb.XGBClassifier(n_estimators=100, max_depth=4, learning_rate=0.1,
                                         use_label_encoder=False, eval_metric="logloss", random_state=42)
            rf_model = RandomForestClassifier(n_estimators=100, max_depth=6, random_state=42, n_jobs=-1)
            lr_model = LogisticRegression(C=1.0, max_iter=500, random_state=42)
            
            self.model = VotingClassifier(
                estimators=[("xgb", xgb_model), ("rf", rf_model), ("lr", lr_model)],
                voting="soft", weights=[3, 2, 1]
            )
            
            self.model.fit(X_train_s, y_train)
            y_pred = self.model.predict(X_test_s)
            report = classification_report(y_test, y_pred, output_dict=True)
            print(f"[CO2 탐지기] 정확도: {report['accuracy']:.3f}")
            
            with open(model_path, "wb") as f:
                pickle.dump({"model": self.model, "scaler": self.scaler}, f)
    
    def predict(self, co2_value: float, history: List[float] = None, sensors_meta=None) -> Dict:
        """CO2 이상 탐지"""
        if history is None:
            history = [co2_value] * 5
        
        features = np.array([history]).reshape(1, -1)
        features_s = self.scaler.transform(features)
        prob = float(self.model.predict_proba(features_s)[0][1])
       
        is_abnormal = prob >= 0.6
        
        # if co2_value > 1200:
        #     is_abnormal = True
        #     prob = max(prob, 0.8)
        
        # sensors_meta 임계값 사용 (하드코딩 제거)
        warn = sensors_meta.get("warning_threshold", 800)  if sensors_meta else 800
        crit = sensors_meta.get("critical_threshold", 1200) if sensors_meta else 1200

        if co2_value > warn:
            prob = max(prob, 0.65); is_abnormal = True
        if co2_value > crit:
            prob = max(prob, 0.9);  is_abnormal = True
       
        if co2_value > crit:
            status = "⚠️ 위험"
        elif co2_value > warn:
            status = "⚠️ 경고"
        else:
            status = "정상"
             
        return {
            "sensor": "co2",
            "value":         round(float(co2_value), 2),
            "abnormal_prob": round(float(prob), 3),
            "is_abnormal":   bool(is_abnormal),
            # "message": f"CO2 {co2_value}ppm - {'⚠️ 이상' if is_abnormal else '정상'}",
            "message":       f"CO2 {co2_value}ppm - {status}",
            "confidence": "높음" if abs(prob - 0.5) > 0.3 else "낮음"
        }


class PM25Detector:
    """PM2.5 이상 탐지"""
    
    def __init__(self):
        self.scaler = StandardScaler()
        self.model = None
        self._load_or_train()
    
    def _load_or_train(self):
        model_path = os.path.join(MODEL_DIR, "pm25_model.pkl")
        os.makedirs(os.path.dirname(model_path), exist_ok=True)
        
        if os.path.exists(model_path):
            with open(model_path, "rb") as f:
                saved = pickle.load(f)
                self.model = saved["model"]
                self.scaler = saved["scaler"]
            print("[PM2.5 탐지기] 저장된 모델 로드 완료")
        else:
            print("[PM2.5 탐지기] 모델 학습 시작...")
            X, y = _generate_pm25_dataset()
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            
            X_train_s = self.scaler.fit_transform(X_train)
            X_test_s = self.scaler.transform(X_test)
            
            xgb_model = xgb.XGBClassifier(n_estimators=100, max_depth=4, learning_rate=0.1,
                                         use_label_encoder=False, eval_metric="logloss", random_state=42)
            rf_model = RandomForestClassifier(n_estimators=100, max_depth=6, random_state=42, n_jobs=-1)
            lr_model = LogisticRegression(C=1.0, max_iter=500, random_state=42)
            
            self.model = VotingClassifier(
                estimators=[("xgb", xgb_model), ("rf", rf_model), ("lr", lr_model)],
                voting="soft", weights=[3, 2, 1]
            )
            
            self.model.fit(X_train_s, y_train)
            y_pred = self.model.predict(X_test_s)
            report = classification_report(y_test, y_pred, output_dict=True)
            print(f"[PM2.5 탐지기] 정확도: {report['accuracy']:.3f}")
            
            with open(model_path, "wb") as f:
                pickle.dump({"model": self.model, "scaler": self.scaler}, f)
    
    def predict(self, pm25_value: float, history: List[float] = None, sensors_meta=None) -> Dict:
        """PM2.5 이상 탐지"""
        if history is None:
            history = [pm25_value] * 5
        
        features = np.array([history]).reshape(1, -1)
        features_s = self.scaler.transform(features)
        prob = float(self.model.predict_proba(features_s)[0][1])
        
        is_abnormal = prob >= 0.6
        
        if pm25_value > 75:
            is_abnormal = True
            prob = max(prob, 0.8)
        
        warn = sensors_meta.get("warning_threshold", 35) if sensors_meta else 35
        crit = sensors_meta.get("critical_threshold", 75) if sensors_meta else 75

        if pm25_value > warn:
            prob = max(prob, 0.65); is_abnormal = True
        if pm25_value > crit:
            prob = max(prob, 0.9);  is_abnormal = True
            
        return {
            "sensor": "pm25",
            "value":         round(float(pm25_value), 2),
            "abnormal_prob": round(float(prob), 3),
            "is_abnormal":   bool(is_abnormal),
            "message": f"PM2.5 {pm25_value}μg/m³ - {'⚠️ 이상' if is_abnormal else '정상'}",
            "confidence": "높음" if abs(prob - 0.5) > 0.3 else "낮음"
        }


class EnsembleAnomalyDetector:
    """통합 이상 탐지 시스템"""
    
    def __init__(self):
        self.temp_detector = TemperatureDetector()
        self.humidity_detector = HumidityDetector()
        self.co2_detector = CO2Detector()
        self.pm25_detector = PM25Detector()
        print("✅ 통합 이상 탐지 시스템 초기화 완료(EnsembleAnomalyDetector)")
    
    def detect_anomalies(self, room_id: str, readings: Dict, sensors_meta: Dict = None) -> Dict:
        """모든 센서의 이상 탐지"""
        results = {
            "room_id": room_id,
            "timestamp": datetime.now().isoformat(),
            "sensors": [],
            "overall_status": "정상",
            "risk_level": 0,
        }
        
        # 각 센서별 탐지
        if "temperature" in readings:
            meta = sensors_meta.get("temperature") if sensors_meta else None
            temp_result = self.temp_detector.predict(readings["temperature"], sensors_meta=meta)
            results["sensors"].append(temp_result)
        
        if "humidity" in readings:
            meta = sensors_meta.get("humidity") if sensors_meta else None
            humidity_result = self.humidity_detector.predict(readings["humidity"], sensors_meta=meta)
            results["sensors"].append(humidity_result)

        if "co2" in readings:
            meta = sensors_meta.get("co2") if sensors_meta else None
            co2_result = self.co2_detector.predict(readings["co2"], sensors_meta=meta)
            results["sensors"].append(co2_result)

        if "pm25" in readings:
            meta = sensors_meta.get("pm25") if sensors_meta else None
            pm25_result = self.pm25_detector.predict(readings["pm25"], sensors_meta=meta)
            results["sensors"].append(pm25_result)
        
        # 종합 위험도 계산
        abnormal_count = sum(1 for s in results["sensors"] if s["is_abnormal"])
        total_count = len(results["sensors"])
        
        if abnormal_count == 0:
            results["overall_status"] = "정상"
            results["risk_level"] = 0
        elif abnormal_count == 1:
            results["overall_status"] = "경고"
            results["risk_level"] = 1
        else:
            results["overall_status"] = "위험"
            results["risk_level"] = 2
        
        return results
