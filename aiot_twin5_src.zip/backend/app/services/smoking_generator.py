"""
흡연 감지용 가상 센서 데이터 제너레이터.
실제 흡연 시 나타나는 CO₂·PM2.5·VOC·온도 패턴을 시뮬레이션합니다.

흡연 패턴 특징:
  - VOC(휘발성유기화합물): 흡연 시작 10초 내 급등 → 가장 강한 신호
  - PM2.5: 흡연 중 급등, 흡연 종료 후 서서히 감소
  - CO₂: 완만한 상승 (사람 호흡 + 연소)
  - 온도: 미세하게 상승 (연소열)
"""
import numpy as np
import time
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from datetime import datetime


@dataclass
class SmokingEvent:
    """흡연 이벤트 1회 기록"""
    start_time: float
    duration_sec: float = 300.0   # 기본 5분
    room_id: str = ""
    intensity: float = 1.0        # 0.5(약한 흡연) ~ 1.5(강한 흡연)


class SmokingDataGenerator:
    """
    흡연 감지용 가상 센서 데이터 생성기.
    정상 상태와 흡연 상태의 센서 패턴을 구분해서 생성합니다.
    XGBoost 학습 데이터 및 실시간 추론 입력으로 사용됩니다.
    """

    # 정상 범위 (평상 시)
    NORMAL = {
        "co2":         (400,  600),
        "pm25":        (5,    20),
        "voc":         (50,   150),   # ppb
        "temperature": (20,   26),
        "humidity":    (40,   60),
    }

    # 흡연 시 최대값 (강도 1.0 기준)
    SMOKING_PEAK = {
        "co2":         1800,
        "pm25":        180,
        "voc":         1200,
        "temperature": 27.5,
        "humidity":    55,
    }

    def __init__(self, room_id: str):
        self.room_id = room_id
        self._event: Optional[SmokingEvent] = None
        np.random.seed(hash(room_id) % 9999)

    def trigger_smoking(self, duration_sec: float = 300, intensity: float = 1.0):
        """시연용: 흡연 이벤트 강제 발생"""
        self._event = SmokingEvent(
            start_time=time.time(),
            duration_sec=duration_sec,
            room_id=self.room_id,
            intensity=intensity,
        )
        print(f"[SmokingGen] {self.room_id}: 흡연 이벤트 시작 ({duration_sec}초)")

    def generate(self) -> Dict[str, float]:
        """현재 시각의 센서값 1세트 생성"""
        base = self._base_readings()

        if self._event is not None:
            elapsed = time.time() - self._event.start_time
            if elapsed > self._event.duration_sec + 300:  # 5분 환기 후 종료
                self._event = None
            else:
                base = self._apply_smoking_pattern(base, elapsed)

        # 미세 노이즈 추가
        for key in base:
            noise_ratio = 0.015
            base[key] += np.random.normal(0, base[key] * noise_ratio)
            base[key] = round(max(0.0, base[key]), 2)

        return base

    def _base_readings(self) -> Dict[str, float]:
        hour = datetime.now().hour
        wf = 0.3 + 0.5 * max(0, min(1, (hour - 8) / 10))  # 업무시간 보정
        return {
            "co2":         self.NORMAL["co2"][0]  + wf * 200,
            "pm25":        self.NORMAL["pm25"][0] + wf * 8,
            "voc":         self.NORMAL["voc"][0]  + wf * 40,
            "temperature": 22.0 + wf * 2,
            "humidity":    50.0 + wf * 5,
        }

    def _apply_smoking_pattern(self, base: Dict, elapsed: float) -> Dict:
    
        """
        흡연 단계별 센서 패턴 적용.
        단계: 상승(0~30초) → 피크(30~240초) → 하강(240~300초) → 환기(300~600초)
        """
        if not self._event:
            return base

        iv = getattr(self._event, "intensity", 1.0)
    
        # iv = self._event.intensity
        dur = self._event.duration_sec

        if elapsed < 30:                     # 상승 단계
            progress = elapsed / 30
            phase = "rising"
        elif elapsed < dur:                  # 피크 단계
            progress = 1.0
            phase = "peak"
        elif elapsed < dur + 60:             # 하강 단계
            progress = 1.0 - (elapsed - dur) / 60
            phase = "falling"
        else:                                # 환기 단계
            progress = max(0, 1.0 - (elapsed - dur - 60) / 240)
            phase = "ventilation"

        result = dict(base)

        # VOC: 흡연 시 가장 먼저, 가장 크게 반응
        voc_factor = progress * iv
        result["voc"]  = base["voc"]  + (self.SMOKING_PEAK["voc"]  - base["voc"])  * voc_factor

        # PM2.5: 상승 빠르고 하강 느림 (입자 잔류)
        pm_factor = progress * iv * (1.2 if phase in ("peak", "falling") else 1.0)
        result["pm25"] = base["pm25"] + (self.SMOKING_PEAK["pm25"] - base["pm25"]) * min(pm_factor, 1.0)

        # CO₂: 완만하게 상승
        co2_factor = progress * iv * 0.6
        result["co2"]  = base["co2"]  + (self.SMOKING_PEAK["co2"]  - base["co2"])  * co2_factor

        # 온도: 미세 상승
        result["temperature"] = base["temperature"] + progress * iv * 1.2

        return result

    def is_smoking(self) -> bool:
        if self._event is None:
            return False
        elapsed = time.time() - self._event.start_time
        return elapsed < self._event.duration_sec


def generate_training_dataset(n_normal: int = 500, n_smoking: int = 300) -> tuple:
    """
    XGBoost 학습용 데이터셋 생성.
    반환: (X: numpy array, y: numpy array)
    특성: [co2, pm25, voc, temperature, humidity,
           co2_delta, pm25_delta, voc_delta]  # 변화율 포함
    """
    # gen = SmokingDataGenerator("dummy")
    # # 🔥 강제 이벤트 생성
    # gen._event = type("E", (), {"intensity": 1.0})()
    
    gen = SmokingDataGenerator("train-room")
    X, y = [], []

    # 정상 데이터
    for _ in range(n_normal):
        base = gen._base_readings()
        prev = gen._base_readings()
        features = [
            base["co2"], base["pm25"], base["voc"],
            base["temperature"], base["humidity"],
            base["co2"]  - prev["co2"],    # 변화율
            base["pm25"] - prev["pm25"],
            base["voc"]  - prev["voc"],
        ]
        # 노이즈 추가
        features = [f + np.random.normal(0, abs(f) * 0.03) for f in features]
        X.append(features)
        y.append(0)  # 정상

    # 흡연 데이터 (다양한 단계)
    for i in range(n_smoking):
        elapsed = np.random.uniform(10, 280)
        intensity = np.random.uniform(0.6, 1.4)
        base = gen._base_readings()
        prev_base = gen._base_readings()

        smoking = gen._apply_smoking_pattern(base.copy(), elapsed)
        smoking_prev = gen._apply_smoking_pattern(prev_base.copy(), max(0, elapsed - 5))

        features = [
            smoking["co2"], smoking["pm25"], smoking["voc"],
            smoking["temperature"], smoking["humidity"],
            smoking["co2"]  - smoking_prev["co2"],
            smoking["pm25"] - smoking_prev["pm25"],
            smoking["voc"]  - smoking_prev["voc"],
        ]
        features = [f + np.random.normal(0, abs(f) * 0.02) for f in features]
        X.append(features)
        y.append(1)  # 흡연

    import numpy as np_inner
    return np_inner.array(X), np_inner.array(y)
