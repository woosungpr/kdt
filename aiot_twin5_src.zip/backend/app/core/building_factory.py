"""
데모용 건물 트윈 초기화.
4개 구역(사무공간, 회의실, 로비, 서버실)에 각각 맞는 가상 센서를 부착합니다.
"""
from app.models.twin import BuildingTwin, RoomTwin, SensorSpec


def create_demo_building() -> BuildingTwin:
    building = BuildingTwin(
        building_id="bldg-01",
        name="KDT 스마트 오피스",
        total_floors=3,
    )

    # ── 1층 ──────────────────────────────────────────────
    lobby = RoomTwin(
        room_id="r-101", name="로비", floor=1,
        area_m2=80, zone="lobby", capacity=50,
        position={"x": 0, "y": 0, "z": 0, "w": 8, "d": 10, "h": 4},
    )
    _attach_standard_sensors(lobby, co2_warning=900, co2_critical=1200)      
    # 로비만 더 엄격한 CO2 기준 적용
    lobby.sensors['co2'] = SensorSpec(
        sensor_id="r-101-co2", sensor_type="co2",
        unit="ppm", normal_min=400, normal_max=800,    # ← 정상 max 낮춤
        warning_threshold=900, critical_threshold=1200,
        description="이산화탄소 (로비)",
    )
  
    building.add_room(lobby)

    # ── 2층 ──────────────────────────────────────────────
    office1 = RoomTwin(
        room_id="r-201", name="사무공간 A", floor=2,
        area_m2=60, zone="office", capacity=20,
        position={"x": 0, "y": 4, "z": 0, "w": 8, "d": 7.5, "h": 3},
    )
    _attach_standard_sensors(office1)
    building.add_room(office1)

    meeting1 = RoomTwin(
        room_id="r-202", name="회의실 1", floor=2,
        area_m2=25, zone="meeting", capacity=10,
        position={"x": 8, "y": 4, "z": 0, "w": 5, "d": 5, "h": 3},
    )
    _attach_standard_sensors(meeting1, co2_critical=1200)
    building.add_room(meeting1)

    # ── 3층 ──────────────────────────────────────────────
    office2 = RoomTwin(
        room_id="r-301", name="사무공간 B", floor=3,
        area_m2=60, zone="office", capacity=20,
        position={"x": 0, "y": 8, "z": 0, "w": 8, "d": 7.5, "h": 3},
    )
    _attach_standard_sensors(office2)
    building.add_room(office2)

    server = RoomTwin(
        room_id="r-302", name="서버실", floor=3,
        area_m2=15, zone="lab", capacity=2,
        position={"x": 8, "y": 8, "z": 0, "w": 3, "d": 5, "h": 3},
    )
    _attach_server_room_sensors(server)
    building.add_room(server)

    return building


def _attach_standard_sensors(room: RoomTwin, co2_warning: float = 1000, co2_critical: float = 1500):
    room.attach_sensor(SensorSpec(
        sensor_id=f"{room.room_id}-temp", sensor_type="temperature",
        unit="°C", normal_min=18, normal_max=26,
        warning_threshold=28, critical_threshold=32,
        description="실내 온도",
    ))
    room.attach_sensor(SensorSpec(
        sensor_id=f"{room.room_id}-hum", sensor_type="humidity",
        unit="%", normal_min=40, normal_max=60,
        warning_threshold=70, critical_threshold=80,
        description="상대 습도",
    ))
    room.attach_sensor(SensorSpec(
        sensor_id=f"{room.room_id}-co2", sensor_type="co2",
        unit="ppm", normal_min=400, normal_max=1000,
        warning_threshold=1000, critical_threshold=co2_critical,
        description="이산화탄소",
    ))
    room.attach_sensor(SensorSpec(
        sensor_id=f"{room.room_id}-pm25", sensor_type="pm25",
        unit="μg/m³", normal_min=0, normal_max=35,
        warning_threshold=35, critical_threshold=75,
        description="미세먼지(PM2.5)",
    ))


def _attach_server_room_sensors(room: RoomTwin):
    room.attach_sensor(SensorSpec(
        sensor_id=f"{room.room_id}-temp", sensor_type="temperature",
        unit="°C", normal_min=15, normal_max=24,
        warning_threshold=27, critical_threshold=30,
        description="서버실 온도",
    ))
    room.attach_sensor(SensorSpec(
        sensor_id=f"{room.room_id}-hum", sensor_type="humidity",
        unit="%", normal_min=40, normal_max=55,
        warning_threshold=60, critical_threshold=70,
        description="서버실 습도",
    ))
    room.attach_sensor(SensorSpec(
        sensor_id=f"{room.room_id}-noise", sensor_type="noise",
        unit="dB", normal_min=30, normal_max=70,
        warning_threshold=75, critical_threshold=85,
        description="소음 레벨",
    ))
    room.attach_sensor(SensorSpec(                        # ✅ 추가
        sensor_id=f"{room.room_id}-pm25", sensor_type="pm25",
        unit="μg/m³", normal_min=0, normal_max=15,       # 서버실은 더 엄격한 기준
        warning_threshold=25, critical_threshold=50,
        description="미세먼지(PM2.5)",
    ))
    