"""
FastAPI 메인 앱 - OpenAI 버전
"""

from app.services.smoking_generator import SmokingDataGenerator
from app.services.ai_models.smoking_detector import SmokingDetector
# from app.services.ai_models.fire_detector import YOLOFireDetector #,FireVideoGenerator
from app.services.ai_models.fire_detector import MultiRoomCameraManager

import asyncio
import json
from datetime import datetime
from typing import Dict, List
from dotenv import load_dotenv

# .env 파일 로드 (반드시 다른 import 전에)
load_dotenv()

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from app.core.building_factory import create_demo_building
from app.services.generator import TelemetryGenerator, LSTMPatternEngine
from app.services.agent import AIoTAgent

from app.services.ensemble_detector import EnsembleAnomalyDetector

from contextlib import asynccontextmanager

building = None
generators = {}
smoking_generators = {}
lstm_engine = None
agent = None
smoking_detector = None
# fire_gen = None
# yolo_detector = None
camera_manager = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global building, generators, smoking_generators
    global lstm_engine, agent
    global smoking_detector #, yolo_detector #,fire_gen
    global camera_manager   # 추가
    global ensemble_detector  # ← 추가
 
    building = create_demo_building()    

    generators = {
        rid: TelemetryGenerator(room)
        for rid, room in building.rooms.items()
    }
    smoking_generators = {
        rid: SmokingDataGenerator(rid)
        for rid in building.rooms
    }
    
    lstm_engine = LSTMPatternEngine()
    
    agent = AIoTAgent()

    camera_manager = MultiRoomCameraManager(list(building.rooms.keys()))

    # 🔥 여기로 이동
    smoking_detector = SmokingDetector()
    
    # fire_gen = FireVideoGenerator()
    # yolo_detector = YOLOFireDetector()

    # 🔥 새로 추가
    ensemble_detector = EnsembleAnomalyDetector()
    print("✅ 통합 이상 탐지 시스템 초기화 완료(lifespan)")


    yield
    print("🛑 시스템 종료")



# FastAPI 생성 시 lifespan 등록
app = FastAPI(
    title="AIoT Digital Twin API",
    version="2.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
    allow_credentials=True,
)

active_ws: List[WebSocket] = []

ensemble_detector = None
 

# ── WebSocket ──────────────────────────────────────────
async def _ws_stream(websocket: WebSocket):
    await websocket.accept()
    active_ws.append(websocket)
    try:
        while True:
            payload = _collect_all_readings()
            # await websocket.send_text(json.dumps(payload, ensure_ascii=False))
            await websocket.send_json(payload)  # 👈 중요
            await asyncio.sleep(0.3)
    except WebSocketDisconnect:
        print("WebSocket disconnected")

    except Exception as e:
        print("WebSocket error:", e)        
    # except Exception:
    #     pass
    finally:
        if websocket in active_ws:
            active_ws.remove(websocket)


@app.websocket("/ws/telemetry")
async def ws_telemetry(websocket: WebSocket):
    await _ws_stream(websocket)


@app.websocket("/ws/sensor-data")
async def ws_sensor_data(websocket: WebSocket):
    await _ws_stream(websocket)


# ── 데이터 수집 ────────────────────────────────────────
def _collect_all_readings() -> Dict:
    rooms_data = {}
    for rid, room in building.rooms.items():
        readings = generators[rid].generate()
        snapshot = room.update_state(readings)
        predictions = []
        if len(room.state_history) >= 5:
            predictions = lstm_engine.predict_next(room.state_history, steps=6)
        rooms_data[rid] = {
            "room_id": rid,
            "name": room.name,
            "floor": room.floor,
            "zone": room.zone,
            "position": room.position,
            "readings": readings,
            "status": snapshot["overall_status"],
            "occupancy_estimate": snapshot["occupancy_estimate"],
            "predictions": predictions,
            "sensors_meta": {
                k: {
                    "unit": v.unit,
                    "normal_min": v.normal_min,
                    "normal_max": v.normal_max,
                    "warning_threshold": v.warning_threshold,
                    "critical_threshold": v.critical_threshold,
                    "description": v.description,
                }
                for k, v in room.sensors.items()
            },
        }
    return {
        "timestamp": datetime.now().isoformat(),
        "building": building.get_building_summary(),
        "rooms": rooms_data,
    }


# ── REST API ───────────────────────────────────────────
class ScenarioRequest(BaseModel):
    room_id: str
    scenario: str
    duration: int = 60


class ChatRequest(BaseModel):
    question: str


@app.get("/")
async def root():
    return {"status": "ok", "message": "AIoT Digital Twin API (OpenAI 버전)"}


@app.post("/api/scenario")
async def inject_scenario(req: ScenarioRequest):
    if req.room_id not in generators:
        raise HTTPException(404, f"Room {req.room_id} not found")
    generators[req.room_id].inject_scenario(req.scenario, req.duration)
    return {"status": "ok", "message": f"{building.rooms[req.room_id].name}에 '{req.scenario}' 시나리오 주입됨"}


@app.post("/api/analyze/{room_id}")
async def analyze_room(room_id: str):
    if room_id not in building.rooms:
        raise HTTPException(404, "Room not found")
    result = agent.analyze_room(building.rooms[room_id])
    if not result:
        return {"status": "normal", "message": "현재 이상 없음"}
    return result


@app.post("/api/analyze/building/all")
async def analyze_building():
    results = agent.analyze_building(building)
    return {"count": len(results), "alerts": results}


@app.post("/api/chat")
async def chat(req: ChatRequest):
    answer = agent.chat(req.question, building)
    return {"question": req.question, "answer": answer}


@app.get("/api/building/summary")
async def building_summary():
    return building.get_building_summary()


@app.get("/api/rooms")
async def list_rooms():
    return [
        {
            "room_id": rid,
            "name": r.name,
            "floor": r.floor,
            "zone": r.zone,
            "area_m2": r.area_m2,
            "capacity": r.capacity,
            "position": r.position,
        }
        for rid, r in building.rooms.items()
    ]


@app.get("/api/rooms/{room_id}/history")
async def room_history(room_id: str, limit: int = 60):
    if room_id not in building.rooms:
        raise HTTPException(404, "Room not found")
    return {"room_id": room_id, "history": building.rooms[room_id].state_history[-limit:]}


@app.get("/api/agent/log")
async def agent_log(limit: int = 20):
    return agent.action_log[-limit:]


@app.get("/api/scenarios")
async def list_scenarios():
    return {"scenarios": [
        {"id": "co2_spike",       "label": "CO₂ 급증",  "desc": "CO₂ 위험 수준 상승"},
        {"id": "overheating",     "label": "과열",       "desc": "온도 임계치 초과"},
        {"id": "humidity_crisis", "label": "습도 위기",  "desc": "습도 80% 이상"},
        {"id": "multi_alarm",     "label": "복합 경보",  "desc": "온도+CO₂ 동시 경고"},
        {"id": "normal",          "label": "정상 복구",  "desc": "시나리오 해제"},
    ]}


@app.get("/api/smoking/all/status")
async def get_all_smoking_status():
    results = []
    for rid in building.rooms:
        gen      = smoking_generators[rid]
        readings = gen.generate()
        det      = smoking_detector.predict(rid, readings)
        if det["smoking_prob"] > 0.2:
            results.append({
                "room_id":   rid,
                "room_name": building.rooms[rid].name,
                "detection": det,
                "readings":  readings,
            })
    return {"count": len(results), "alerts": results}


# ── 시연용 트리거 ───────────────────────────────────────
class SmokingTriggerRequest(BaseModel):
    room_id:      str
    duration_sec: float = 300
    intensity:    float = 1.0

class FireTriggerRequest(BaseModel):
    x_ratio: float = 0.5
    y_ratio: float = 0.8


# ── 5개 공간 통합 카메라 WebSocket ─────────────────────
@app.websocket("/ws/cameras")
async def cameras_ws(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            frames = camera_manager.get_all_frames()
            alerts = camera_manager.get_alert_rooms()
            await websocket.send_text(json.dumps({
                "frames":    frames,
                "alerts":    alerts,
                "timestamp": datetime.now().isoformat(),
            }, ensure_ascii=False))
            await asyncio.sleep(0.12)   # ~8fps
    except Exception:
        pass
 
 
# ── 흡연 감지 API ──────────────────────────────────────
@app.get("/api/smoking/{room_id}")
async def get_smoking_status(room_id: str):
    if room_id not in building.rooms:
        raise HTTPException(404, "Room not found")
    readings = smoking_generators[room_id].generate()
    result   = smoking_detector.predict(room_id, readings)
    return {
        "room_id":   room_id,
        "room_name": building.rooms[room_id].name,
        "readings":  readings,
        "detection": result,
    }
 
 
# ── 시연 트리거 ────────────────────────────────────────
class RoomEventRequest(BaseModel):
    room_id:  str
    x_ratio:  float = 0.5
    y_ratio:  float = 0.75
    duration: float = 180.0
 
 
@app.post("/api/trigger/fire")
async def trigger_fire(req: RoomEventRequest):
    if req.room_id not in building.rooms:
        raise HTTPException(404, "Room not found")
    camera_manager.trigger_fire(req.room_id, req.x_ratio, req.y_ratio)
    return {"status": "ok",
            "message": f"{building.rooms[req.room_id].name} 화재 발생",
            "room_id": req.room_id}
 
 
@app.post("/api/trigger/fire/stop")
async def stop_fire(req: RoomEventRequest):
    camera_manager.stop_fire(req.room_id)
    return {"status": "ok", "message": f"{building.rooms[req.room_id].name} 화재 진압"}
 
 
@app.post("/api/trigger/smoking")
async def trigger_smoking(req: RoomEventRequest):
    if req.room_id not in building.rooms:
        raise HTTPException(404, "Room not found")
    camera_manager.trigger_smoking(req.room_id)
    smoking_generators[req.room_id].trigger_smoking(req.duration)
    return {"status": "ok",
            "message": f"{building.rooms[req.room_id].name} 흡연 감지",
            "room_id": req.room_id}
 
 
@app.post("/api/trigger/smoking/stop")
async def stop_smoking(req: RoomEventRequest):
    camera_manager.stop_smoking(req.room_id)
    return {"status": "ok", "message": "흡연 이벤트 종료"}
 
 
@app.get("/api/alerts/active")
async def active_alerts():
    return {"alerts": camera_manager.get_alert_rooms()}



# ── 시나리오 요청 클래스 추가 ────────────────────────────────
class AnomalyTriggerRequest(BaseModel):
    room_id: str
    anomaly_type: str  # "temperature" | "humidity" | "co2" | "pm25"
    severity: str      # "warning" | "critical"
    duration: int = 60  # 지속 시간 (초)
    
# 복합 경보 요청클래스
class MultiAnomalyRequest(BaseModel):
    room_id: str
    severity: str
    duration: int = 60
    
# ── 각 센서별 시나리오 발생 엔드포인트 ────────────────────────
@app.post("/api/trigger/anomaly")
async def trigger_anomaly(req: AnomalyTriggerRequest):
    """
    센서 이상 시나리오 발생
    
    예시:
    POST /api/trigger/anomaly
    {
        "room_id": "r-101",
        "anomaly_type": "temperature",
        "severity": "critical"
    }
    """
    if req.room_id not in building.rooms:
        raise HTTPException(404, "Room not found")
    
    room = building.rooms[req.room_id]
    
    # 심각도에 따른 수치 설정
    if req.severity == "warning":
        multiplier = 1.2
    else:  # critical
        multiplier = 1.5
    
    # 센서별 이상 값 주입
    if req.anomaly_type == "temperature":
        # 온도를 35°C로 설정 (과열)
        generators[req.room_id].inject_scenario("overheating", req.duration)
        message = f"🌡️ {room.name}에서 과열 감지 (심각도: {req.severity})"
    
    elif req.anomaly_type == "humidity":
        # 습도를 90% 이상으로 설정
        generators[req.room_id].inject_scenario("humidity_crisis", req.duration)
        message = f"💧 {room.name}에서 습도 이상 감지 (심각도: {req.severity})"
    
    elif req.anomaly_type == "co2":
        # CO2를 1500ppm 이상으로 설정
        generators[req.room_id].inject_scenario("co2_spike", req.duration)
        message = f"🌫️ {room.name}에서 CO2 급증 감지 (심각도: {req.severity})"
    
    elif req.anomaly_type == "pm25":
        # PM2.5를 높은 수치로 설정 (별도 처리)
        generators[req.room_id].inject_scenario("pm25_spike", req.duration)  # ✅ 수정
        message = f"🌪️ {room.name}에서 미세먼지 이상 감지 (심각도: {req.severity})"
 
    elif req.anomaly_type == "normal":
        generators[req.room_id].inject_scenario("normal", req.duration)
        message = f"✅ {room.name} 정상 복구"
       
    else:
        raise HTTPException(400, "Invalid anomaly_type")
    
    # 채팅에 시스템 메시지 추가
    await broadcast({
        "type": "anomaly_alert",
        "room_id": req.room_id,
        "anomaly_type": req.anomaly_type,
        "severity": req.severity,
        "message": message,
        "timestamp": datetime.now().isoformat(),
    })
    
    return {
        "status": "ok",
        "message": message,
        "room_id": req.room_id,
        "anomaly_type": req.anomaly_type,
        "severity": req.severity,
    }

# ── 공통 헬퍼 (파일 상단 함수로 추가) ──────────────────
def _get_sensors_meta(room):
    return {
        k: {
            "normal_min":         v.normal_min,
            "normal_max":         v.normal_max,
            "warning_threshold":  v.warning_threshold,
            "critical_threshold": v.critical_threshold,
        }
        for k, v in room.sensors.items()
    }
    
# ── 모든 센서 종합 분석 엔드포인트 ────────────────────────────
@app.post("/api/analyze/ensemble/{room_id}")
async def analyze_ensemble(room_id: str):
    """
    특정 공간의 모든 센서 종합 분석 (ML 모델 기반)
    
    POST /api/analyze/ensemble/r-101
    """
    if room_id not in building.rooms:
        raise HTTPException(404, "Room not found")
    
    room = building.rooms[room_id]
    # readings = generators[room_id].generate()
    
     # ✅ 새로 generate() 하지 않고 WebSocket이 이미 업데이트한 최신값 사용
    if room.state_history:
        readings = room.state_history[-1]["readings"]
    else:
        readings = generators[room_id].generate()  # fallback
    
    # ✅ sensors_meta(임계값)도 함께 전달
    sensors_meta = {
        k: {
            "normal_min":          v.normal_min,
            "normal_max":          v.normal_max,
            "warning_threshold":   v.warning_threshold,
            "critical_threshold":  v.critical_threshold,
        }
        for k, v in room.sensors.items()
    }
        
    # 통합 이상 탐지
    result = ensemble_detector.detect_anomalies(room_id, readings, _get_sensors_meta(room))
    
    return {
        "room_id": room_id,
        "room_name": room.name,
        "readings": readings,
        "analysis_result": result,
        "timestamp": datetime.now().isoformat(),
    }


# ── 한 번에 여러 센서 이상 발생 ────────────────────────────────
@app.post("/api/trigger/multi-anomalies")
async def trigger_multi_anomalies(req: MultiAnomalyRequest):
    """
    여러 센서 동시 이상 발생 (위험도 높음)
    
    POST /api/trigger/multi-anomalies
    {
        "room_id": "r-101",
        "severity": "critical"
    }
    """
    if req.room_id not in building.rooms:
        raise HTTPException(404, "Room not found")
    
    room = building.rooms[req.room_id]
    
    # 온도 + CO2 동시 발생
    generators[req.room_id].inject_scenario("multi_alarm", req.duration)
    
    message = f"⚠️ {room.name}에서 복합 경보 발생 (온도 + CO2)"
    
    await broadcast({
        "type": "multi_anomaly_alert",
        "room_id": req.room_id,
        "severity": req.severity,
        "message": message,
        "timestamp": datetime.now().isoformat(),
    })
    
    return {
        "status": "ok",
        "message": message,
        "room_id": req.room_id,
        "anomalies": ["temperature", "co2"],
    }


# ── 실시간 센서 모니터링 (ML 기반) ────────────────────────────
@app.get("/api/realtime/anomaly/{room_id}")
async def realtime_anomaly_check(room_id: str):
    """
    실시간 센서 이상 체크 (ML 모델 기반)
    
    GET /api/realtime/anomaly/r-101
    """
    if room_id not in building.rooms:
        raise HTTPException(404, "Room not found")
    
    room = building.rooms[room_id]
    
    # ✅ 동일하게 최신 history 사용
    if room.state_history:
        readings = room.state_history[-1]["readings"]
    else:
        readings = generators[room_id].generate()
    
    # ML 기반 종합 분석
    result = ensemble_detector.detect_anomalies(room_id, readings, _get_sensors_meta(room))
    
    # 이상 감지 시 즉시 alert
    if result["overall_status"] != "정상":
        await broadcast({
            "type": "realtime_anomaly",
            "room_id": room_id,
            "result": result,
            "timestamp": datetime.now().isoformat(),
        })
    
    return result


# ── 전체 건물의 이상 상태 요약 ────────────────────────────────
@app.get("/api/building/anomaly-summary")
async def building_anomaly_summary():
    """
    전체 건물의 센서 이상 상태 요약
    
    GET /api/building/anomaly-summary
    """
    summary = {
        "timestamp": datetime.now().isoformat(),
        "building": building.name,
        "total_rooms": len(building.rooms),
        "anomaly_rooms": [],
        "critical_count": 0,
        "warning_count": 0,
        "normal_count": 0,
    }
    
    for rid, room in building.rooms.items():
        # ✅ 동일하게 수정
        if room.state_history:
            readings = room.state_history[-1]["readings"]
        else:
            readings = generators[rid].generate()
            
        result = ensemble_detector.detect_anomalies(rid, readings, _get_sensors_meta(room))
        
        if result["overall_status"] == "위험":
            summary["anomaly_rooms"].append({
                "room_id": rid,
                "room_name": room.name,
                "status": "위험",
                "abnormal_sensors": [s["sensor"] for s in result["sensors"] if s["is_abnormal"]],
            })
            summary["critical_count"] += 1
        elif result["overall_status"] == "경고":
            summary["warning_count"] += 1
        else:
            summary["normal_count"] += 1
    
    return summary

async def broadcast(message: dict):
    dead_ws = []
    for ws in active_ws:
        try:
            await ws.send_json(message)
        except:
            dead_ws.append(ws)

    # 끊긴 ws 정리
    for ws in dead_ws:
        if ws in active_ws:
            active_ws.remove(ws)
  
            

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
